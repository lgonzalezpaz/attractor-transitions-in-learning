# Data

## Included

`dosenbach160_networks.csv` — the mapping from the 160 Dosenbach ROIs to their
six canonical functional networks, with MNI coordinates. Column `roi_num`
is 1-indexed and corresponds directly to the column order of the ABIDE
`rois_dosenbach160` derivative files.

## Fetched at run time

`01_build_cohort.py` and `02_extract_dynamics.py` download the ABIDE I
Preprocessed phenotypic file and ROI time series from the public S3 bucket:

```
https://s3.amazonaws.com/fcp-indi/data/Projects/ABIDE_Initiative/
```

No registration or data use certification is required. See `../LICENSE-DATA.md`
for the terms that apply.

To work offline, place `abide_pheno.csv` (the file
`Phenotypic_V1_0b_preprocessed1.csv`) in this directory before running.
