1. Hirota T, King BH. Autism spectrum disorder: a review. JAMA. 2023;329(2):157-168. doi:10.1001/jama.2022.23661

2. Lai MC, Anagnostou E, Wiznitzer M, Allison C, Baron-Cohen S. Evidence-based support for autistic people across the lifespan: maximising potential, minimising barriers, and optimising the person–environment fit. The Lancet Neurology. 2020;19(5):434-451. doi:10.1016/S1474-4422(20)30034-X

3. Supekar K, Ryali S, Mistry P, Menon V. Aberrant dynamics of cognitive control and motor circuits predict distinct restricted and repetitive behaviors in children with autism. Nat Commun. 2021;12(1):3537. doi:10.1038/s41467-021-23822-5

4. Watanabe T, Rees G. Brain network dynamics in high-functioning individuals with autism. Nat Commun. 2017;8(1):16048. doi:10.1038/ncomms16048

5. Watanabe D, Watanabe T. Distinct Frontoparietal Brain Dynamics Underlying the Co-Occurrence of Autism and ADHD. eNeuro. 2023;10(7):ENEURO.0146-23.2023. doi:10.1523/ENEURO.0146-23.2023

6. Watanabe T, Yamasue H. Noninvasive reduction of neural rigidity alters autistic behaviors in humans. Nat Neurosci. 2025;28(6):1348-1360. doi:10.1038/s41593-025-01961-y

7. Duch W. Autism Spectrum Disorder and Deep Attractors in Neurodynamics. In: Multiscale models of brain disorders. Springer; 2019. p. 135-146. doi:10.1007/978-3-030-18830-6_13

8. Fuhr BP, Perl YS, Severino I, Kringelbach ML, Deco G, Ruhé HG, et al. Dynamic Functional Synchronization Profiles in Autism Differ by Spatial Scale and Along Hierarchical Cortical Gradients. Biological Psychiatry Global Open Science. 2026;6(5):100787. doi:10.1016/j.bpsgos.2026.100787

9. Jenkinson R, Milne E, Thompson A. The relationship between intolerance of uncertainty and anxiety in autism: A systematic literature review and meta-analysis. Autism. 2020;24(8):1933-1944. doi:10.1177/1362361320932437

10. Boulter C, Freeston M, South M, Rodgers J. Intolerance of Uncertainty as a Framework for Understanding Anxiety in Children and Adolescents with Autism Spectrum Disorders. J Autism Dev Disord. 2014;44(6):1391-1402. doi:10.1007/s10803-013-2001-x

11. Wigham S, Rodgers J, South M, McConachie H, Freeston M. The Interplay Between Sensory Processing Abnormalities, Intolerance of Uncertainty, Anxiety and Restricted and Repetitive Behaviours in Autism Spectrum Disorder. J Autism Dev Disord. 2015;45(4):943-952. doi:10.1007/s10803-014-2248-x

12. Gunn KCM, Delafield-Butt JT. Teaching Children With Autism Spectrum Disorder With Restricted Interests. Review of Educational Research. 2016;86(2):408-430. doi:10.3102/0034654315604027

13. Koegel R, Kim S, Koegel L, Schwartzman B. Improving Socialization for High School Students with ASD by Using Their Preferred Interests. J Autism Dev Disord. 2013;43(9):2121-2134. doi:10.1007/s10803-013-1765-3

14. Wright B, Kingsley E, Cooper C, Biggs K, Bursnall M, Wang HI, et al. I-SOCIALISE: Results from a cluster randomised controlled trial investigating the social competence and isolation of children with autism taking part in LEGO
                    <sup>®</sup>
                    based therapy (‘Play Brick Therapy’) clubs in school environments. Autism. 2023:136236132311596. doi:10.1177/13623613231159699

15. Virues-Ortega J, Julio FM, Pastor-Barriuso R. The TEACCH program for children and adults with autism: A meta-analysis of intervention studies. Clinical Psychology Review. 2013;33(8):940-953. doi:10.1016/j.cpr.2013.07.005

16. Zhu Y, Zhang M, Ma D, Wang P. Efficacy of structured teaching program for rehabilitation of children with autism spectrum disorder: A systematic review and meta-analysis. Pak J Med Sci. 2025;41(9):2658-2666. doi:10.12669/pjms.41.9.12634

17. Tiede G, Walton KM. Meta-analysis of naturalistic developmental behavioral interventions for young children with autism spectrum disorder. Autism. 2019;23(8):2080-2095. doi:10.1177/1362361319836371

18. Sandbank M, Bottema-Beutel K, Crowley LaPoint S, Feldman JI, Barrett DJ, Caldwell N, et al. Autism intervention meta-analysis of early childhood studies (Project AIM): updated systematic review and secondary analysis. BMJ. 2023;383:e076733. doi:10.1136/bmj-2023-076733

19. Leaf JB, Cihon JH, Ferguson JL, Milne CM, Leaf R, McEachin J. Comparing Error Correction to Errorless Learning: A Randomized Clinical Trial. Analysis Verbal Behav. 2020;36(1):1-20. doi:10.1007/s40616-019-00124-y

20. Markham VA, Giles AF, Roderique-Davies G, Adshead V, Tamiaki G, May RJ. Applications of within-stimulus errorless learning methods for teaching discrimination skills to individuals with intellectual and developmental disabilities: A systematic review. Research in Developmental Disabilities. 2020;97:103521. doi:10.1016/j.ridd.2019.103521

21. Ezaki T, Watanabe T, Ohzeki M, Masuda N. Energy landscape analysis of neuroimaging data. Phil Trans R Soc A. 2017;375(2096):20160287. doi:10.1098/rsta.2016.0287

22. Ye L, Feng J, Li C. Controlling brain dynamics: Landscape and transition path for working memory. PLoS Comput Biol. 2023;19(9):e1011446. doi:10.1371/journal.pcbi.1011446

23. Gu S, Pasqualetti F, Cieslak M, Telesford QK, Yu AB, Kahn AE, et al. Controllability of structural brain networks. Nat Commun. 2015;6(1). doi:10.1038/ncomms9414

24. Kim JZ, Soffer JM, Kahn AE, Vettel JM, Pasqualetti F, Bassett DS. Role of graph architecture in controlling dynamical networks with applications to neural systems. Nature Phys. 2018;14(1):91-98. doi:10.1038/nphys4268

25. Karrer TM, Kim JZ, Stiso J, Kahn AE, Pasqualetti F, Habel U, et al. A practical guide to methodological considerations in the controllability of structural brain networks. J Neural Eng. 2020;17(2):026031. doi:10.1088/1741-2552/ab6e8b

26. Deco G, Martí D, Ledberg A, Reig R, Sanchez Vives MV. Effective Reduced Diffusion-Models: A Data Driven Approach to the Analysis of Neuronal Dynamics. PLoS Comput Biol. 2009;5(12):e1000587. doi:10.1371/journal.pcbi.1000587

27. Defoort M, Puller V, Bourgeois O, Pistolesi F, Collin E. Scaling laws for the bifurcation escape rate in a nanomechanical resonator. Phys Rev E. 2015;92(5). doi:10.1103/PhysRevE.92.050903

28. Kramers H. Brownian motion in a field of force and the diffusion model of chemical reactions. Physica. 1940;7(4):284-304. doi:10.1016/S0031-8914(40)90098-2

29. Hänggi P, Talkner P, Borkovec M. Reaction-rate theory: fifty years after Kramers. Rev Mod Phys. 1990;62(2):251-341. doi:10.1103/RevModPhys.62.251

30. Creaser J, Tsaneva-Atanasova K, Ashwin P. Sequential Noise-Induced Escapes for Oscillatory Network Dynamics. SIAM J Appl Dyn Syst. 2018;17(1):500-525. doi:10.1137/17M1126412

31. Strogatz SH, Mirollo RE. Stability of incoherence in a population of coupled oscillators. J Stat Phys. 1991;63(3-4):613-635. doi:10.1007/BF01029202

32. Sakaguchi H. Cooperative Phenomena in Coupled Oscillator Systems under External Fields. Progress of Theoretical Physics. 1988;79(1):39-46. doi:10.1143/PTP.79.39

33. Acebrón JA, Bonilla LL, Pérez Vicente CJ, Ritort F, Spigler R. The Kuramoto model: A simple paradigm for synchronization phenomena. Rev Mod Phys. 2005;77(1):137-185. doi:10.1103/RevModPhys.77.137

34. [no author listed]. Noise-Induced Phenomena in Slow-Fast Dynamical Systems. Springer-Verlag; 2006. doi:10.1007/1-84628-186-5

35. Bergeot B, Berglund N, Zogheib I. The dynamic saddle–node bifurcation with noise on the slow variable. Nonlinearity. 2026;39(7):075004. doi:10.1088/1361-6544/ae7ec0

36. Di Martino A, Yan CG, Li Q, Denio E, Castellanos FX, Alaerts K, et al. The autism brain imaging data exchange: towards a large-scale evaluation of the intrinsic brain architecture in autism. Mol Psychiatry. 2014;19(6):659-667. doi:10.1038/mp.2013.78

37. Cameron C, Yassine B, Carlton C, Francois C, Alan E, András J, et al. The Neuro Bureau Preprocessing Initiative: open sharing of preprocessed neuroimaging data and derivatives. Front Neuroinform. 2013;7. doi:10.3389/conf.fninf.2013.09.00041

38. Power JD, Barnes KA, Snyder AZ, Schlaggar BL, Petersen SE. Spurious but systematic correlations in functional connectivity MRI networks arise from subject motion. NeuroImage. 2012;59(3):2142-2154. doi:10.1016/j.neuroimage.2011.10.018

39. Power JD, Mitra A, Laumann TO, Snyder AZ, Schlaggar BL, Petersen SE. Methods to detect, characterize, and remove motion artifact in resting state fMRI. NeuroImage. 2014;84:320-341. doi:10.1016/j.neuroimage.2013.08.048

40. Ciric R, Wolf DH, Power JD, Roalf DR, Baum GL, Ruparel K, et al. Benchmarking of participant-level confound regression strategies for the control of motion artifact in studies of functional connectivity. NeuroImage. 2017;154:174-187. doi:10.1016/j.neuroimage.2017.03.020

41. Dosenbach NUF, Nardos B, Cohen AL, Fair DA, Power JD, Church JA, et al. Prediction of Individual Brain Maturity Using fMRI. Science. 2010;329(5997):1358-1361. doi:10.1126/science.1194144

42. Glerean E, Salmi J, Lahnakoski JM, Jääskeläinen IP, Sams M. Functional Magnetic Resonance Imaging Phase Synchronization as a Measure of Dynamic Functional Connectivity. Brain Connectivity. 2012;2(2):91-101. doi:10.1089/brain.2011.0068

43. Bedrosian E. A product theorem for Hilbert transforms. Proc IEEE. 1963;51(5):868-869. doi:10.1109/PROC.1963.2308

44. Gabor D. Theory of communication. Part 1: The analysis of information. Journal of the Institution of Electrical Engineers - Part III: Radio and Communication Engineering. 1946;93(26):429-441. doi:10.1049/ji-3-2.1946.0074

45. Shanahan M. Metastable chimera states in community-structured oscillator networks. Chaos: An Interdisciplinary Journal of Nonlinear Science. 2010;20(1). doi:10.1063/1.3305451

46. Wildie M, Shanahan M. Metastability and chimera states in modular delay and pulse-coupled oscillator networks. Chaos: An Interdisciplinary Journal of Nonlinear Science. 2012;22(4). doi:10.1063/1.4766592

47. Deco G, Kringelbach ML, Jirsa VK, Ritter P. The dynamics of resting fluctuations in the brain: metastability and its dynamical cortical core. Sci Rep. 2017;7(1). doi:10.1038/s41598-017-03073-5

48. Hosaka Y, Hieda T, Li R, Hayashi K, Jimura K, Matsui T. Surrogate data analyses of the energy landscape analysis of resting-state brain activity. Front Neural Circuits. 2025;19. doi:10.3389/fncir.2025.1500227

49. Hindriks R, Adhikari M, Murayama Y, Ganzetti M, Mantini D, Logothetis N, et al. Can sliding-window correlations reveal dynamic functional connectivity in resting-state fMRI?. NeuroImage. 2016;127:242-256. doi:10.1016/j.neuroimage.2015.11.055

50. Liégeois R, Laumann TO, Snyder AZ, Zhou J, Yeo BT. Interpreting temporal fluctuations in resting-state functional connectivity MRI. NeuroImage. 2017;163:437-455. doi:10.1016/j.neuroimage.2017.09.012

51. Zalesky A, Fornito A, Cocchi L, Gollo LL, Breakspear M. Time-resolved resting-state brain networks. Proc Natl Acad Sci USA. 2014;111(28):10341-10346. doi:10.1073/pnas.1400181111

52. Prichard D, Theiler J. Generating surrogate data for time series with several simultaneously measured variables. Phys Rev Lett. 1994;73(7):951-954. doi:10.1103/PhysRevLett.73.951

53. Theiler J, Eubank S, Longtin A, Galdrikian B, Doyne Farmer J. Testing for nonlinearity in time series: the method of surrogate data. Physica D: Nonlinear Phenomena. 1992;58(1-4):77-94. doi:10.1016/0167-2789(92)90102-S

54. Laird NM, Ware JH. Random-Effects Models for Longitudinal Data. Biometrics. 1982;38(4):963. doi:10.2307/2529876

55. Benjamini Y, Hochberg Y. Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing. Journal of the Royal Statistical Society Series B: Statistical Methodology. 1995;57(1):289-300. doi:10.1111/j.2517-6161.1995.tb02031.x

56. Hedges LV. Distribution Theory for Glass's Estimator of Effect size and Related Estimators. Journal of Educational Statistics. 1981;6(2):107-128. doi:10.3102/10769986006002107

57. Nichols TE, Holmes AP. Nonparametric permutation tests for functional neuroimaging: A primer with examples. Human Brain Mapping. 2002;15(1):1-25. doi:10.1002/hbm.1058

58. Lakens D. Equivalence Tests. Social Psychological and Personality Science. 2017;8(4):355-362. doi:10.1177/1948550617697177

59. Laumann TO, Snyder AZ, Mitra A, Gordon EM, Gratton C, Adeyemo B, et al. On the Stability of BOLD fMRI Correlations. Cereb Cortex. 2017;27(9):4719-4732. doi:10.1093/cercor/bhw265

60. Nozari E, Bertolero MA, Stiso J, Caciagli L, Cornblath EJ, He X, et al. Macroscopic resting-state brain dynamics are best described by linear models. Nat Biomed Eng. 2023;8(1):68-84. doi:10.1038/s41551-023-01117-y

61. Zhang H, Peng D, Tang S, Bi A, Long Y. Aberrant Flexibility of Dynamic Brain Network in Patients with Autism Spectrum Disorder. Bioengineering. 2024;11(9):882. doi:10.3390/bioengineering11090882

62. Kupis L, Goodman ZT, Kircher L, Romero C, Dirks B, Chang C, et al. Altered patterns of brain dynamics linked with body mass index in youth with autism. Autism Research. 2021;14(5):873-886. doi:10.1002/aur.2488

63. Rabany L, Brocke S, Calhoun VD, Pittman B, Corbera S, Wexler BE, et al. Dynamic functional connectivity in schizophrenia and autism spectrum disorder: Convergence, divergence and classification. NeuroImage: Clinical. 2019;24:101966. doi:10.1016/j.nicl.2019.101966

64. Marek S, Tervo-Clemmens B, Calabro FJ, Montez DF, Kay BP, Hatoum AS, et al. Reproducible brain-wide association studies require thousands of individuals. Nature. 2022;603(7902):654-660. doi:10.1038/s41586-022-04492-9

65. Birn RM, Molloy EK, Patriat R, Parker T, Meier TB, Kirk GR, et al. The effect of scan length on the reliability of resting-state fMRI connectivity estimates. NeuroImage. 2013;83:550-558. doi:10.1016/j.neuroimage.2013.05.099

66. Robertson CE, Kravitz DJ, Freyberg J, Baron-Cohen S, Baker CI. Slower Rate of Binocular Rivalry in Autism. J Neurosci. 2013;33(43):16983-16991. doi:10.1523/JNEUROSCI.0448-13.2013

67. Spiegel A, Mentch J, Haskins AJ, Robertson CE. Slower Binocular Rivalry in the Autistic Brain. Current Biology. 2019;29(17):2948-2953.e3. doi:10.1016/j.cub.2019.07.026

68. Watanabe T, Rees G, Masuda N. Atypical intrinsic neural timescale in autism. eLife. 2019;8:e42256. doi:10.7554/eLife.42256
