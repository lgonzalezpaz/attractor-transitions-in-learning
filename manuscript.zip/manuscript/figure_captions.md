## Figure captions

**Figure 1. The model and the two obstructions it creates.**
(**a**) The washboard potential U(φ) = −Δω·φ − K·cos φ of the phase difference between a module and the assembly field, at three values of the detuning ratio a = Δω/K_eff. The locked state sits at a minimum whose escape barrier shrinks as the detuning grows.
(**b**) The forward barrier of equation (6), in units of the effective coupling. It equals 2K_eff at zero detuning and vanishes at the saddle-node, where the locked state is annihilated.
(**c**) Mean escape time from the locked state, equation (9), against noise intensity for three coupling strengths. The horizontal line marks a thirty-minute instructional session. Escape cost is explosive, not graded, in attractor depth.
(**d**) Critical coupling for assembly coherence, equation (12), for a Gaussian frequency density of standard deviation 0.038 rad s⁻¹. Coherence exists only above the curve.
(**e**) The two requirements plotted together: noise must exceed D_esc to leave the attractor within the session and fall below D_c for the assembly to cohere. The shaded region is the feasible window, which closes at low coupling.
(**f**) The feasibility index Λ of equation (13) against assembly coupling, at three levels of assembly coherence. Λ = 1 (horizontal line) is the boundary below which no perturbation can succeed. Higher baseline coherence moves the boundary to the right: a more strongly bound assembly is harder, not easier, to reconfigure by perturbation.
All panels are analytic; none involves fitted data.

**Figure 2. The closed forms reproduce direct stochastic simulation.**
(**a**) Simulated against predicted mean first-passage time out of the locked state, over two coupling strengths, three detunings and barrier-to-noise ratios from 1.5 to 5.0 (1,500 trials per condition, censored maximum-likelihood estimator). The dotted line is identity; the solid line is identity scaled by 1.281. The simulated time exceeds the asymptotic prediction by a constant factor of 1.281 ± 0.041 with no dependence on the barrier-to-noise ratio (slope of log ratio on ΔU/D = 0.0008, P = 0.89), so the Arrhenius exponent is exact and only the asymptotic prefactor requires a finite-noise correction.
(**b**) Mean assembly coherence against coupling scaled to the analytic threshold of equation (12), for 60 modules and for the 5 modules used in the empirical analysis. With 60 modules the transition is sharp at the predicted location. With 5 modules, coherence is 0.48 even at four-tenths of threshold: at a five-network parcellation an order parameter near 0.6 is the finite-size floor, not evidence of a coherent assembly.
(**c**) Delay in unlocking when the detuning is swept through the saddle-node, against sweep rate. The fitted log–log slope is 0.643 against the theoretical two-thirds, bounding how fast a graduated transition may proceed.

**Figure 3. The feasibility boundary, the anchoring gain and the cost of delay.**
(**a**) Λ over assembly coupling and assembly coherence for a thirty-minute session. The contour marks Λ = 1. Red denotes the infeasible region, in which every noise level that frees the prior state within the session has already destroyed assembly coherence.
(**b**) Time to reconfigure by the two routes. Curves are noise-driven escape at three noise intensities, exponential in attractor depth; horizontal lines are anchored entrainment at two anchor strengths, algebraic in the control parameter and independent of noise to leading order. The gain grows without bound as attractors deepen and is negligible when they are shallow.
(**c**) Escape time of an incorrectly learned association against time since first encoding, for three structural consolidation time constants, with the thirty-minute session marked. The argument for preventing initial errors is that the cost of removing them compounds.

**Figure 4. Local estimators fail; simulation-based inversion recovers the identifiable parameters.**
(**a**) Bias in the estimated phase diffusion for a conventional local drift-diffusion regression and for the split-half instrumental-variable construction, across synthetic conditions with known parameters (symmetric-log axis). The finite-size error of a module mean phase inflates the naive estimate by a median of 1,333%; the split-half estimator reduces this to 19% but cannot repair the coupling estimate, which remains attenuated by a median of 84% because the shrinkage of sin(φ + ε) towards sin φ is multiplicative.
(**b**) Recovered against true assembly coupling for held-out simulations inverted against the library built from the remaining replicates (median and interquartile range).
(**c**) The same for phase noise. Coupling and noise are recovered with Spearman ρ of 0.58 and 0.65; within-module coupling (ρ = 0.36) is not interpreted.

**Figure 5. Empirical dynamics and inverted parameters in 477 school-age participants.**
(**a**–**d**) Distributions by diagnostic group for triad metastability, triad switching rate, inverted assembly coupling and inverted phase noise. Markers show the median, bars the interquartile range.
(**e**) Standardised group differences with 95% confidence intervals from linear mixed models with site as a random intercept, adjusted for age, sex, full-scale IQ, mean framewise displacement, retained volumes and eye status. No contrast survives correction for multiple comparisons; all intervals lie within ±0.38.
(**f**) Distribution of the feasibility index. The vertical line marks Λ = 1. Both groups lie overwhelmingly in the feasible regime.
(**g**) Required instructional gain on a log₂ scale, with the line marking G* = 1.

**Figure 6. The observables barely exceed stationary linear surrogates.**
(**a**) Standardised within-participant difference between each observable and the mean of five multivariate phase-randomised surrogates of the same participant's data, which preserve every auto- and cross-spectrum and therefore all linear lagged and instantaneous cross-correlations. Absolute values range from 0.017 to 0.201.
(**b**) Real against surrogate metastability for every participant, with the identity line.
(**c**) The same for the switching rate. At this spatial scale and these scan durations the dynamic quantities carry almost no information beyond the covariance structure and the spectra.

**Figure 7. Instructional protocols at equal coupling budget.**
(**a**) Success rate against instructional coupling for the three protocols. The abrupt protocol saturates at one quarter and never rises further; the graduated protocol reaches ceiling at a coupling of 0.32 and the anchored protocol at 0.64.
(**b**) Success rate against the strength of the prior attractor. Entrenchment penalises the anchored protocol most.
(**c**) For the abrupt protocol, success rate and retained assembly coherence against the protocol noise. Raising the noise leaves the success rate at its ceiling while monotonically degrading the coherence that success requires — the feasibility theorem expressed in the full model.
Each point aggregates ten independent runs per parameter combination (640 runs in total).
