### Table 1

**Table 1. Participant characteristics.** Values are mean ± SD unless stated. P values are from Mann–Whitney U tests for continuous variables and a chi-squared test for sex. Full-scale IQ, framewise displacement and sex were included as covariates in all models.

| Characteristic | Autistic | Non-autistic | P |
|---|---|---|---|
| n | 214 | 263 | — |
| Age at scan (years) | 12.9 ± 2.8 | 12.9 ± 2.9 | 0.883 |
| Full-scale IQ | 105.0 ± 17.9 | 109.9 ± 13.3 | 0.001 |
| Mean framewise displacement (mm) | 0.091 ± 0.045 | 0.075 ± 0.042 | 0.000 |
| Usable scan duration (s) | 353.7 ± 105.6 | 360.5 ± 101.6 | 0.168 |
| Retained volumes | 178.8 ± 50.7 | 180.7 ± 51.0 | 0.857 |
| Male (%) | 85 | 76 | 0.025 |
| Sites contributing | 13 | 13 | — |
| ADI-R domain C (RRB) available | 170 | 0 | — |
| ADOS calibrated RRB available | 138 | 6 | — |
| SRS total available | 94 | 111 | — |


### Table 2

**Table 2. Model quantities estimated in the cohort (n = 477).** Inverted parameters come from the simulation-based inversion; derived quantities follow from the equations indicated. The frequency dispersion was fixed at a calibrated value because it was not identifiable from these observables.

| Quantity | Symbol | Median (IQR), whole cohort | Source |
|---|---|---|---|
| Assembly coupling | K | 0.098 (0.057–0.165) | inverted |
| Phase noise amplitude | σ | 1.15 (0.80–1.15) | inverted |
| Noise intensity | D = σ²/2 | 0.661 (0.320–0.661) | derived |
| Within-module coupling | K_in | 0.10 (0.06–0.16) | inverted (weakly identified) |
| Assembly coherence | ⟨R̄⟩ | 0.598 (0.535–0.671) | measured |
| Metastability | SD[R̄] | 0.223 (0.204–0.245) | measured |
| Effective pair coupling | K_eff = K·R̄ | 0.0617 (0.0287–0.1021) | derived |
| Module frequency dispersion | s | 0.0377 rad s⁻¹ | fixed (calibrated) |
| Barrier of the locked state | ΔU₊ | 0.0803 (0.0313–0.1217) | derived, eq. (6) |
| Barrier in noise units | ΔU₊/D | 0.113 (0.053–0.170) | derived |
| Escape time | log₁₀ τ_esc (s) | 1.90 (1.84–2.10) | derived, eq. (9) |
| Feasibility index | Λ | 2.51 (2.07–3.12) | derived, eq. (13) |
| Required instructional gain | G* | 1.00 (1.00–1.49) | derived |
| Anchoring gain | log₁₀(τ_esc/T_lock) | 0.31 (0.29–0.34) | derived, eq. (15) |
| Participants with a locked state | — | 60.4% | derived |
| Participants below the coherence threshold | — | 37.3% | derived |
| Participants with Λ < 1 | — | 1.5% | derived |


### Table 3

**Table 3. Categorical contrasts between autistic and non-autistic participants.** β is the standardised group difference from a linear mixed model with site as a random intercept, adjusted for age, sex, full-scale IQ, mean framewise displacement, retained volumes and eye status. q values are Benjamini–Hochberg corrected within the observable and latent families. Permutation P values are from 4,000 site-stratified permutations. LOSO indicates whether the sign of β was preserved when each site was removed in turn. The lower n for barrier-dependent quantities reflects participants without a locked state.

| Outcome | n | β (95% CI) | Hedges' g (95% CI) | P | q (FDR) | P (perm.) | LOSO |
|---|---|---|---|---|---|---|---|
| Assembly coherence ⟨R̄⟩ | 477 | -0.057 (-0.222 to 0.107) | 0.084 (-0.097 to 0.264) | 0.495 | 0.742 | 0.287 | no |
| Metastability SD[R̄] | 477 | -0.046 (-0.231 to 0.140) | -0.007 (-0.188 to 0.173) | 0.630 | 0.809 | 0.775 | yes |
| Within-module coherence | 477 | -0.216 (-0.374 to -0.059) | -0.076 (-0.257 to 0.104) | 0.007 | 0.113 | 0.299 | yes |
| Inter-module phase locking | 477 | -0.077 (-0.247 to 0.092) | 0.063 (-0.117 to 0.244) | 0.371 | 0.742 | 0.466 | no |
| Switching rate | 477 | 0.121 (-0.061 to 0.304) | 0.076 (-0.105 to 0.256) | 0.192 | 0.565 | 0.428 | yes |
| Triad coherence | 477 | -0.059 (-0.234 to 0.116) | 0.102 (-0.078 to 0.283) | 0.510 | 0.742 | 0.216 | no |
| Triad metastability | 477 | -0.116 (-0.298 to 0.066) | -0.182 (-0.363 to -0.001) | 0.212 | 0.565 | 0.033 | yes |
| Triad phase locking | 477 | -0.028 (-0.203 to 0.148) | 0.092 (-0.088 to 0.273) | 0.758 | 0.809 | 0.275 | no |
| Triad switching rate | 477 | 0.198 (0.014 to 0.382) | 0.202 (0.022 to 0.383) | 0.035 | 0.278 | 0.033 | yes |
| Assembly coupling K | 477 | 0.066 (-0.110 to 0.242) | 0.093 (-0.087 to 0.274) | 0.460 | 0.742 | 0.194 | no |
| Phase noise σ | 477 | 0.129 (-0.052 to 0.310) | 0.039 (-0.141 to 0.220) | 0.163 | 0.565 | 0.596 | yes |
| Within-module coupling K_in | 477 | -0.011 (-0.197 to 0.175) | -0.018 (-0.198 to 0.162) | 0.907 | 0.907 | 0.894 | no |
| Barrier ΔU₊ | 288 | 0.053 (-0.187 to 0.293) | 0.125 (-0.107 to 0.357) | 0.664 | 0.809 | 0.193 | no |
| Noise intensity D | 477 | 0.146 (-0.034 to 0.327) | 0.052 (-0.128 to 0.233) | 0.112 | 0.565 | 0.523 | yes |
| Feasibility index Λ | 288 | -0.135 (-0.375 to 0.104) | -0.170 (-0.402 to 0.062) | 0.269 | 0.614 | 0.219 | yes |
| log₁₀ escape time | 288 | -0.039 (-0.279 to 0.200) | -0.057 (-0.289 to 0.175) | 0.747 | 0.809 | 0.413 | no |


### Table 4

**Table 4. Observables compared with each participant's own multivariate phase-randomised surrogates.** d_z is the standardised within-participant difference; P values are from Wilcoxon signed-rank tests. The final columns give the standardised group difference in the surrogate-corrected excess and its Mann–Whitney P value.

| Observable | Real (mean) | Surrogate (mean) | d_z | P | Group effect on excess (g) | P |
|---|---|---|---|---|---|---|
| Assembly coherence | 0.604 | 0.611 | -0.140 | 0.0359 | 0.058 | 0.439 |
| Metastability | 0.223 | 0.219 | 0.115 | 0.0180 | -0.055 | 0.432 |
| Within-module coherence | 0.410 | 0.413 | -0.201 | 0.0002 | 0.049 | 0.683 |
| Inter-module phase locking | 0.379 | 0.387 | -0.129 | 0.0746 | 0.119 | 0.187 |
| Phase-slip rate | 0.00572 | 0.00565 | 0.065 | 0.4653 | -0.029 | 0.796 |
| P(k ≥ 4) | 0.580 | 0.590 | -0.102 | 0.0358 | 0.011 | 0.833 |
| Switching rate | 2.373 | 2.362 | 0.017 | 0.9170 | -0.005 | 0.893 |
| Triad coherence | 0.690 | 0.694 | -0.090 | 0.1776 | 0.131 | 0.308 |
| Triad metastability | 0.235 | 0.232 | 0.069 | 0.0213 | -0.198 | 0.053 |
| Triad locking | 0.393 | 0.400 | -0.084 | 0.2003 | 0.098 | 0.760 |
| Triad switching | 2.244 | 2.294 | -0.078 | 0.0248 | 0.134 | 0.214 |
| Module frequency dispersion | 0.01124 | 0.01090 | 0.079 | 0.1779 | 0.097 | 0.276 |
