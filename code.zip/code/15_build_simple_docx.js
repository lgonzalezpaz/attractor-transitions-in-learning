
/* 15_build_simple_docx.js — short standalone documents (title page, highlights). */
const fs = require("fs"); const path = require("path");
const { Document, Packer, Paragraph, TextRun, AlignmentType } = require("docx");
const MAN = path.resolve(__dirname, "..", "manuscript");
const FONT = "Times New Roman";
function inline(t, size, bold) {
  const runs = []; const re = /(\*\*[^*]+\*\*|\*[^*]+\*)/g; let last = 0, m;
  const push = (x, b) => { if (x) runs.push(new TextRun({ text: x, font: FONT, size, bold: b || bold })); };
  while ((m = re.exec(t)) !== null) { push(t.slice(last, m.index));
    const k = m[0];
    if (k.startsWith("**")) push(k.slice(2, -2), true); else push(k.slice(1, -1));
    last = m.index + k.length; }
  push(t.slice(last)); return runs;
}
function build(srcFile, outName, title) {
  const md = fs.readFileSync(path.join(MAN, srcFile), "utf8");
  const kids = [];
  md.split("\n").forEach((L) => {
    const v = L.trim();
    if (!v) { return; }
    if (v.startsWith("# ")) {
      kids.push(new Paragraph({ children: [new TextRun({ text: v.slice(2), font: FONT, size: 32, bold: true })],
        spacing: { after: 240, line: 360, lineRule: "auto" } })); return; }
    if (v.startsWith("## ")) {
      kids.push(new Paragraph({ children: [new TextRun({ text: v.slice(3), font: FONT, size: 26, bold: true })],
        spacing: { before: 300, after: 140, line: 360, lineRule: "auto" } })); return; }
    if (v.startsWith("- ")) {
      kids.push(new Paragraph({ children: inline(v.slice(2), 24), bullet: { level: 0 },
        spacing: { after: 120, line: 360, lineRule: "auto" } })); return; }
    kids.push(new Paragraph({ children: inline(v, 24),
      spacing: { after: 140, line: 360, lineRule: "auto" } }));
  });
  const doc = new Document({ title,
    styles: { default: { document: { run: { font: FONT, size: 24, color: "000000" } } } },
    sections: [{ properties: { page: { size: { width: 12240, height: 15840 },
      margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } }, children: kids }] });
  return Packer.toBuffer(doc).then((b) => {
    fs.writeFileSync(path.join(MAN, outName), b);
    console.log("wrote", outName, (b.length / 1024).toFixed(0) + " KB"); });
}
build(process.argv[2], process.argv[3], process.argv[4] || "")
  .catch((e) => { console.error(e); process.exit(1); });
