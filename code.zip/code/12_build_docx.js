/*
 * 12_build_docx.js — Assemble the manuscript DOCX from the markdown sources.
 *
 * Applies the journal style required by the manuscript specification:
 * US Letter, 1-inch margins, Times New Roman 12 pt body, double spacing,
 * no first-line indent, continuous line numbers in the left margin, page
 * numbers top right, equations centred as editable text with right-aligned
 * numbers, level-1 and level-2 headings in sentence case without numbering,
 * and a 10 pt reference list.
 */
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  PageNumber, Header, Table, TableRow, TableCell, WidthType, BorderStyle,
  TabStopType, TabStopPosition, LineNumberRestartFormat, ShadingType,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const MAN = path.join(ROOT, "manuscript");

const FONT = "Times New Roman";
const BODY = 24;          // half-points -> 12 pt
const DOUBLE = { line: 480, lineRule: "auto", after: 120 };
const SINGLE15 = { line: 276, lineRule: "auto", after: 100 };
const CONTENT_W = 9360;   // 6.5 inch in DXA

// ---------------------------------------------------------------- inline ---
function inline(text, opts = {}) {
  const size = opts.size || BODY;
  const runs = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^[0-9,–-]+\^|`[^`]+`)/g;
  let last = 0, m;
  const push = (t, extra) => {
    if (t === "") return;
    runs.push(new TextRun({ text: t, font: FONT, size, ...extra }));
  };
  while ((m = re.exec(text)) !== null) {
    push(text.slice(last, m.index), opts.base || {});
    const tok = m[0];
    if (tok.startsWith("**")) push(tok.slice(2, -2), { ...opts.base, bold: true });
    else if (tok.startsWith("^")) push(tok.slice(1, -1), { ...opts.base, superScript: true });
    else if (tok.startsWith("`")) push(tok.slice(1, -1), { ...opts.base, font: "Cambria Math" });
    else push(tok.slice(1, -1), { ...opts.base, italics: true });
    last = m.index + tok.length;
  }
  push(text.slice(last), opts.base || {});
  return runs;
}

const para = (text, opts = {}) =>
  new Paragraph({
    children: inline(text, opts),
    spacing: opts.spacing || DOUBLE,
    alignment: opts.alignment || AlignmentType.LEFT,
    keepNext: opts.keepNext || false,
  });

// --------------------------------------------------------------- headings ---
const h1 = (t) => new Paragraph({
  children: [new TextRun({ text: t, font: FONT, size: 28, bold: true })],
  spacing: { before: 360, after: 180, line: 360, lineRule: "auto" },
  keepNext: true,
});
const h2 = (t) => new Paragraph({
  children: [new TextRun({ text: t, font: FONT, size: 24, bold: true })],
  spacing: { before: 260, after: 120, line: 360, lineRule: "auto" },
  keepNext: true,
});

// -------------------------------------------------------------- equations ---
function equation(line) {
  const m = line.match(/^(.*?)\s{2,}\((\d+)\)\s*$/);
  const body = m ? m[1].trimEnd() : line;
  const num = m ? "(" + m[2] + ")" : null;
  const kids = [new TextRun({ text: body, font: "Cambria Math", size: BODY })];
  if (num) {
    kids.push(new TextRun({ text: "\t", font: FONT, size: BODY }));
    kids.push(new TextRun({ text: num, font: FONT, size: BODY }));
  }
  return new Paragraph({
    children: kids,
    spacing: { line: 300, lineRule: "auto", before: 120, after: 120 },
    tabStops: [{ type: TabStopType.RIGHT, position: CONTENT_W }],
    indent: { left: 360 },
  });
}

// ------------------------------------------------------------------ table ---
function mdTable(rows) {
  const header = rows[0];
  const body = rows.slice(2);
  const n = header.length;
  const colW = Math.floor(CONTENT_W / n);
  const widths = Array(n).fill(colW);
  widths[0] = CONTENT_W - colW * (n - 1);
  const mk = (cells, isHead) => new TableRow({
    tableHeader: isHead,
    children: cells.map((c, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: isHead ? { type: ShadingType.CLEAR, fill: "EFEFEF" } : undefined,
      margins: { top: 60, bottom: 60, left: 90, right: 90 },
      children: [new Paragraph({
        children: inline(c, { size: 18, base: isHead ? { bold: true } : {} }),
        spacing: { line: 240, lineRule: "auto", after: 0 },
      })],
    })),
  });
  return new Table({
    columnWidths: widths,
    width: { size: CONTENT_W, type: WidthType.DXA },
    rows: [mk(header, true), ...body.map((r) => mk(r, false))],
    borders: {
      top: { style: BorderStyle.SINGLE, size: 6 },
      bottom: { style: BorderStyle.SINGLE, size: 6 },
      left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: "BFBFBF" },
      insideVertical: { style: BorderStyle.NONE },
    },
  });
}

// ------------------------------------------------------------------ parse ---
function parseBlocks(md) {
  const lines = md.split("\n");
  const out = [];
  let i = 0;
  while (i < lines.length) {
    const L = lines[i];
    if (L.trim() === "" || L.trim() === "---") { i++; continue; }
    if (L.startsWith("```")) {
      i++;
      const buf = [];
      while (i < lines.length && !lines[i].startsWith("```")) { buf.push(lines[i]); i++; }
      i++;
      buf.forEach((b) => { if (b.trim()) out.push({ t: "eq", v: b }); });
      continue;
    }
    if (L.startsWith("| ")) {
      const rows = [];
      while (i < lines.length && lines[i].startsWith("|")) {
        rows.push(lines[i].split("|").slice(1, -1).map((c) => c.trim()));
        i++;
      }
      out.push({ t: "table", v: rows });
      continue;
    }
    if (L.startsWith("### ")) { out.push({ t: "h2", v: L.slice(4) }); i++; continue; }
    if (L.startsWith("## ")) { out.push({ t: "h1", v: L.slice(3) }); i++; continue; }
    if (L.startsWith("# ")) { out.push({ t: "title", v: L.slice(2) }); i++; continue; }
    out.push({ t: "p", v: L.trim() });
    i++;
  }
  return out;
}

// ------------------------------------------------------------------ build ---
function build() {
  const man = fs.readFileSync(path.join(MAN, "manuscript.md"), "utf8");
  const refs = fs.readFileSync(path.join(MAN, "references.md"), "utf8");
  const tabs = fs.readFileSync(path.join(MAN, "tables.md"), "utf8");
  const caps = fs.readFileSync(path.join(MAN, "figure_captions.md"), "utf8");

  const kids = [];
  const blocks = parseBlocks(man);
  let section = "";

  blocks.forEach((b, idx) => {
    if (b.t === "title") {
      kids.push(new Paragraph({
        children: [new TextRun({ text: b.v, font: FONT, size: 32, bold: true })],
        spacing: { after: 240, line: 360, lineRule: "auto" },
      }));
      return;
    }
    if (b.t === "h1") {
      section = b.v;
      kids.push(h1(b.v));
      return;
    }
    if (b.t === "h2") { kids.push(h2(b.v)); return; }
    if (b.t === "eq") { kids.push(equation(b.v)); return; }
    if (b.t === "table") { kids.push(mdTable(b.v)); return; }

    const v = b.v;
    // title-block lines
    if (idx < 6 && /^\[AUTHOR\]/.test(v)) {
      kids.push(new Paragraph({
        children: [
          new TextRun({ text: "[AUTHOR]", font: FONT, size: BODY }),
          new TextRun({ text: "1,*", font: FONT, size: BODY, superScript: true }),
        ],
        spacing: SINGLE15,
      }));
      return;
    }
    if (idx < 8 && /AFFILIATION/.test(v)) {
      kids.push(new Paragraph({
        children: [
          new TextRun({ text: "1", font: FONT, size: 19, superScript: true }),
          new TextRun({ text: " [AFFILIATION]", font: FONT, size: 19, italics: true }),
        ],
        spacing: SINGLE15,
      }));
      return;
    }
    if (idx < 9 && /Correspondence/.test(v)) {
      kids.push(new Paragraph({
        children: [
          new TextRun({ text: "*", font: FONT, size: 20, superScript: true }),
          new TextRun({ text: "Correspondence: [EMAIL] ([INITIALS])", font: FONT, size: 20 }),
        ],
        spacing: { ...SINGLE15, after: 240 },
      }));
      return;
    }
    if (section === "Abstract") {
      kids.push(para(v, { size: 22, spacing: SINGLE15 }));
      return;
    }
    if (/^\*\*Keywords:/.test(v)) {
      kids.push(para(v, { size: 20, spacing: SINGLE15 }));
      return;
    }
    if (/^\*\*\[Figure .* near here\]\*\*$/.test(v)) {
      kids.push(new Paragraph({
        children: inline(v, { size: BODY }),
        spacing: DOUBLE, alignment: AlignmentType.CENTER,
      }));
      return;
    }
    kids.push(para(v, { size: BODY }));
  });

  // References
  kids.push(new Paragraph({ children: [], spacing: { after: 0 } }));
  refs.split("\n").filter((l) => l.trim()).forEach((l) => {
    kids.push(new Paragraph({
      children: inline(l, { size: 20 }),
      spacing: { line: 276, lineRule: "auto", after: 80 },
      indent: { left: 360, hanging: 360 },
    }));
  });

  // Tables, on a new page
  kids.push(new Paragraph({ children: [], pageBreakBefore: true }));
  kids.push(h1("Tables"));
  parseBlocks(tabs).forEach((b) => {
    if (b.t === "h2") { kids.push(h2(b.v)); return; }
    if (b.t === "table") {
      kids.push(mdTable(b.v));
      kids.push(new Paragraph({ children: [], spacing: { after: 240 } }));
      return;
    }
    if (b.t === "p") {
      kids.push(para(b.v, { size: 20, spacing: SINGLE15, keepNext: true }));
      return;
    }
  });

  // Figure captions, on a new page
  kids.push(new Paragraph({ children: [], pageBreakBefore: true }));
  parseBlocks(caps).forEach((b) => {
    if (b.t === "h1") { kids.push(h1(b.v)); return; }
    if (b.t === "p") { kids.push(para(b.v, { size: BODY, spacing: SINGLE15 })); return; }
  });

  const doc = new Document({
    creator: "[AUTHOR]",
    title: "A feasibility boundary for attractor state transitions",
    styles: {
      default: {
        document: { run: { font: FONT, size: BODY, color: "000000" } },
      },
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
        lineNumbers: {
          countBy: 1, distance: 360,
          restart: LineNumberRestartFormat.CONTINUOUS,
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.RIGHT,
            children: [new TextRun({
              children: [PageNumber.CURRENT], font: FONT, size: 20,
            })],
          })],
        }),
      },
      children: kids,
    }],
  });

  return Packer.toBuffer(doc).then((buf) => {
    const out = path.join(MAN, "Manuscript_Attractor_Feasibility.docx");
    fs.writeFileSync(out, buf);
    console.log("wrote", out, (buf.length / 1024).toFixed(0) + " KB");
  });
}

build().catch((e) => { console.error(e); process.exit(1); });
