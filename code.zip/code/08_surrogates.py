"""
08_surrogates.py — Surrogate control for the ABN observables.

Energy-landscape and dynamic-connectivity features of resting-state fMRI can
be reproduced by stationary linear surrogates, so a measure of attractor
dynamics is uninformative unless it exceeds what the static covariance and the
power spectra already imply.  This script therefore recomputes every observable
on multivariate phase-randomised surrogates of each participant's own data.

The surrogate applies one common random phase shift per frequency to all 160
regions, which preserves every auto- and cross-spectrum exactly -- hence the
static functional connectivity and each region's spectral content -- while
rendering the process stationary and linear-Gaussian.  Two questions are asked:

  (1) Do the observables of the real data differ from those of its own
      surrogates?  If not, the measure adds nothing to static connectivity.
  (2) Do the group contrasts survive after each participant's surrogate mean
      is subtracted?  This isolates the component of any group difference that
      is not attributable to differences in static connectivity or spectra.

Outputs: results/surrogates.csv, results/surrogate_tests.csv
"""
from __future__ import annotations
import io
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd
import requests
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import CORTICAL_MODULES, observables, preprocess  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
RES = os.path.join(ROOT, "results")
BASE = ("https://s3.amazonaws.com/fcp-indi/data/Projects/ABIDE_Initiative/"
        "Outputs/cpac/nofilt_noglobal/rois_dosenbach160")
N_SURR = 5
KEYS = ["sync_R", "meta_R", "r_intra_raw", "plv_bar", "slip_rate_bar",
        "p_k_ge_4", "switch_per_min", "cc_sync", "cc_meta", "cc_plv_bar",
        "cc_switch_per_min", "delta_emp"]


def mvpr_surrogate(x, rng):
    """Multivariate phase-randomised surrogate (one phase shift per frequency,
    shared across channels), preserving all auto- and cross-spectra."""
    T, n = x.shape
    X = np.fft.rfft(x, axis=0)
    nf = X.shape[0]
    phi = rng.uniform(-np.pi, np.pi, nf)
    phi[0] = 0.0
    if T % 2 == 0:
        phi[-1] = 0.0
    return np.fft.irfft(X * np.exp(1j * phi)[:, None], n=T, axis=0)


def fetch(file_id, retries=3):
    url = f"{BASE}/{file_id}_rois_dosenbach160.1D"
    last = None
    for a in range(retries):
        try:
            r = requests.get(url, timeout=180)
            r.raise_for_status()
            return np.loadtxt(io.StringIO(r.text), skiprows=1)
        except Exception as exc:                 # pragma: no cover - network
            last = exc
            time.sleep(2 * (a + 1))
    raise RuntimeError(f"{file_id}: {last}")


def process(row, members, n_surr=N_SURR):
    try:
        arr = fetch(row.FILE_ID)
    except Exception:
        return None
    ts = arr[:, :160]
    if np.any(ts.std(0) == 0) or not np.all(np.isfinite(ts)):
        return None
    tr = float(row.TR)
    rng = np.random.default_rng(abs(hash(row.FILE_ID)) % (2 ** 31))
    out = {"FILE_ID": row.FILE_ID}
    try:
        real = observables(preprocess(ts, tr), tr, members)
    except Exception:
        return None
    for k in KEYS:
        out[f"real_{k}"] = real.get(k, np.nan)
    acc = {k: [] for k in KEYS}
    for _ in range(n_surr):
        try:
            s = observables(preprocess(mvpr_surrogate(ts, rng), tr), tr, members)
        except Exception:
            continue
        for k in KEYS:
            acc[k].append(s.get(k, np.nan))
    for k in KEYS:
        out[f"surr_{k}"] = float(np.nanmean(acc[k])) if acc[k] else np.nan
    return out


def main():
    coh = pd.read_csv(os.path.join(RES, "dynamics_qc.csv"))
    nets = pd.read_csv(os.path.join(DATA, "dosenbach160_networks.csv"))
    members = [np.where(nets.network.values == m)[0] for m in CORTICAL_MODULES]

    rows, t0 = [], time.time()
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = [ex.submit(process, r, members) for r in coh.itertuples()]
        for i, f in enumerate(as_completed(futs), 1):
            r = f.result()
            if r:
                rows.append(r)
            if i % 100 == 0:
                print(f"  {i}/{len(futs)} ({time.time()-t0:.0f}s)", flush=True)

    sur = pd.DataFrame(rows)
    d = coh.merge(sur, on="FILE_ID", how="inner")
    d.to_csv(os.path.join(RES, "surrogates.csv"), index=False)
    print(f"\nN with surrogates: {len(d)}")

    res = []
    for k in KEYS:
        a, b = d[f"real_{k}"].values, d[f"surr_{k}"].values
        ok = np.isfinite(a) & np.isfinite(b)
        a, b = a[ok], b[ok]
        diff = a - b
        t, p = stats.wilcoxon(a, b)
        dz = diff.mean() / diff.std(ddof=1)
        # group contrast on the surrogate-corrected excess
        dd = d.loc[ok].copy()
        dd["excess"] = diff
        g1 = dd.loc[dd.group == "ASD", "excess"]
        g0 = dd.loc[dd.group == "TD", "excess"]
        tg, pg = stats.mannwhitneyu(g1, g0)
        sp = np.sqrt(((len(g1) - 1) * g1.var(ddof=1)
                      + (len(g0) - 1) * g0.var(ddof=1)) / (len(g1) + len(g0) - 2))
        res.append(dict(observable=k, n=len(a), real_mean=a.mean(),
                        surr_mean=b.mean(), excess_mean=diff.mean(),
                        cohen_dz=dz, p_vs_surrogate=p,
                        excess_g=(g1.mean() - g0.mean()) / sp if sp > 0 else np.nan,
                        p_group_on_excess=pg))
    t = pd.DataFrame(res)
    t.to_csv(os.path.join(RES, "surrogate_tests.csv"), index=False)
    pd.set_option("display.width", 220)
    print("\n=== real data versus its own phase-randomised surrogates ===")
    print(t[["observable", "n", "real_mean", "surr_mean", "cohen_dz",
             "p_vs_surrogate", "excess_g", "p_group_on_excess"]]
          .round(4).to_string(index=False))


if __name__ == "__main__":
    main()
