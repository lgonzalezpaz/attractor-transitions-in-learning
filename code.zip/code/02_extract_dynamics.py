"""
02_extract_dynamics.py — Download ABIDE I Preprocessed ROI time series and
compute the ABN observables for every retained participant.

Derivative : rois_dosenbach160  (160 ROIs with canonical network assignments)
Pipeline   : cpac
Strategy   : nofilt_noglobal

Rationale for 'nofilt_noglobal':
  * noglobal — global signal regression removes the spatially coherent
    component of the BOLD signal, which is precisely what the module-level
    order parameter R(t) quantifies; regressing it out would bias every
    synchrony estimate towards zero.
  * nofilt  — band-pass filtering is applied here in one explicit step
    (0.04-0.07 Hz), the band required for instantaneous-phase estimation,
    rather than inheriting a wider 0.01-0.1 Hz filter.

Runs are streamed: each is downloaded, reduced to scalar observables, and
discarded, so peak disk use stays in the megabyte range.
"""
from __future__ import annotations
import io
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd
import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import CORTICAL_MODULES, observables, preprocess  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RES = os.path.join(ROOT, "results")

BASE = ("https://s3.amazonaws.com/fcp-indi/data/Projects/ABIDE_Initiative/"
        "Outputs/cpac/{strategy}/rois_dosenbach160")
N_WORKERS = 8


def fetch(file_id: str, strategy: str, retries: int = 3) -> np.ndarray:
    url = f"{BASE.format(strategy=strategy)}/{file_id}_rois_dosenbach160.1D"
    last = None
    for attempt in range(retries):
        try:
            r = requests.get(url, timeout=180)
            r.raise_for_status()
            return np.loadtxt(io.StringIO(r.text), skiprows=1)
        except Exception as exc:                 # pragma: no cover - network
            last = exc
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"{file_id}: {last}")


def module_members(net_table: pd.DataFrame, modules=CORTICAL_MODULES):
    return [np.where(net_table.network.values == m)[0] for m in modules]


def process(row, members, strategy):
    fid = row.FILE_ID
    try:
        arr = fetch(fid, strategy)
    except Exception as exc:
        return {"FILE_ID": fid, "status": f"download_error: {exc}"}
    if arr.ndim != 2 or arr.shape[1] < 160:
        return {"FILE_ID": fid, "status": f"bad_shape:{arr.shape}"}
    ts = arr[:, :160]
    if np.any(ts.std(axis=0) == 0) or not np.all(np.isfinite(ts)):
        return {"FILE_ID": fid, "status": "degenerate_roi"}
    try:
        ph = preprocess(ts, float(row.TR))
        m = observables(ph, float(row.TR), members)
    except Exception as exc:
        return {"FILE_ID": fid, "status": f"metric_error: {exc}"}
    m.update({"FILE_ID": fid, "status": "ok", "n_tp_raw": int(arr.shape[0])})
    return m


def main(strategy: str = "nofilt_noglobal", out_name: str = "dynamics.csv"):
    coh = pd.read_csv(os.path.join(RES, "cohort.csv"))
    nets = pd.read_csv(os.path.join(DATA, "dosenbach160_networks.csv"))
    members = module_members(nets)
    print("module sizes:", {m: len(ix) for m, ix in zip(CORTICAL_MODULES, members)})

    rows, t0 = [], time.time()
    with ThreadPoolExecutor(max_workers=N_WORKERS) as ex:
        futs = [ex.submit(process, r, members, strategy) for r in coh.itertuples()]
        for i, fut in enumerate(as_completed(futs), 1):
            rows.append(fut.result())
            if i % 100 == 0:
                print(f"  {i}/{len(futs)} ({time.time()-t0:.0f}s)", flush=True)

    df = coh.merge(pd.DataFrame(rows), on="FILE_ID", how="left")
    df.to_csv(os.path.join(RES, out_name), index=False)
    print(df.status.value_counts(dropna=False).to_dict())
    ok = df[df.status == "ok"]
    print("ok:", len(ok), ok.group.value_counts().to_dict())
    print("duration_s pct:", np.nanpercentile(ok.duration_s, [1, 5, 50, 95]).round(0))
    print("n_tp_used pct:", np.nanpercentile(ok.n_tp_used, [1, 5, 50, 95]).round(0))
    print(ok.groupby("TR").n_tp_used.describe()[["count", "min", "50%", "max"]]
          .round(0).to_string())


if __name__ == "__main__":
    strat = sys.argv[1] if len(sys.argv) > 1 else "nofilt_noglobal"
    out = sys.argv[2] if len(sys.argv) > 2 else "dynamics.csv"
    main(strat, out)
