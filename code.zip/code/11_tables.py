"""
11_tables.py — Generate the manuscript tables from the analysis outputs.
"""
from __future__ import annotations
import os

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "manuscript")


def fmt(x, n=3):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "—"
    return f"{x:.{n}f}"


def table1(d):
    rows = []
    def add(label, a, b, p=None, n=1, pct=False):
        if pct:
            rows.append([label, f"{100*a:.0f}", f"{100*b:.0f}",
                         "—" if p is None else f"{p:.3f}"])
        else:
            rows.append([label, a, b, "—" if p is None else f"{p:.3f}"])

    from scipy import stats as sp
    A = d[d.group == "ASD"]; T = d[d.group == "TD"]
    add("n", f"{len(A)}", f"{len(T)}")
    for lab, col in (("Age at scan (years)", "AGE_AT_SCAN"),
                     ("Full-scale IQ", "FIQ"),
                     ("Mean framewise displacement (mm)", "func_mean_fd"),
                     ("Usable scan duration (s)", "duration_s"),
                     ("Retained volumes", "n_tp_used")):
        a, b = A[col].dropna(), T[col].dropna()
        p = sp.mannwhitneyu(a, b)[1]
        dec = 3 if col == "func_mean_fd" else 1
        add(lab, f"{a.mean():.{dec}f} ± {a.std():.{dec}f}",
            f"{b.mean():.{dec}f} ± {b.std():.{dec}f}", p)
    p = sp.chi2_contingency(pd.crosstab(d.group, d.SEX))[1]
    add("Male (%)", (A.SEX == 1).mean(), (T.SEX == 1).mean(), p, pct=True)
    add("Sites contributing", f"{A.SITE_ID.nunique()}", f"{T.SITE_ID.nunique()}")
    for lab, col in (("ADI-R domain C (RRB) available", "ADI_RRB_TOTAL_C"),
                     ("ADOS calibrated RRB available", "ADOS_GOTHAM_RRB"),
                     ("SRS total available", "SRS_RAW_TOTAL")):
        add(lab, f"{A[col].notna().sum()}", f"{T[col].notna().sum()}")
    hdr = ["Characteristic", "Autistic", "Non-autistic", "P"]
    return hdr, rows


def table2(d):
    hdr = ["Quantity", "Symbol", "Median (IQR), whole cohort", "Source"]
    def q(col, n=3):
        v = d[col].dropna()
        return f"{v.median():.{n}f} ({v.quantile(.25):.{n}f}–{v.quantile(.75):.{n}f})"
    rows = [
        ["Assembly coupling", "K", q("K_out_hat"), "inverted"],
        ["Phase noise amplitude", "σ", q("sigma_hat", 2), "inverted"],
        ["Noise intensity", "D = σ²/2", q("D_hat", 3), "derived"],
        ["Within-module coupling", "K_in", q("K_in_hat", 2),
         "inverted (weakly identified)"],
        ["Assembly coherence", "⟨R̄⟩", q("sync_R"), "measured"],
        ["Metastability", "SD[R̄]", q("meta_R"), "measured"],
        ["Effective pair coupling", "K_eff = K·R̄", q("K_eff_hat", 4), "derived"],
        ["Module frequency dispersion", "s", f"{d.s_rad_hat.median():.4f} rad s⁻¹",
         "fixed (calibrated)"],
        ["Barrier of the locked state", "ΔU₊", q("dU_hat", 4), "derived, eq. (6)"],
        ["Barrier in noise units", "ΔU₊/D", q("dU_over_D_hat", 3), "derived"],
        ["Escape time", "log₁₀ τ_esc (s)", q("tau_esc_hat_log10", 2),
         "derived, eq. (9)"],
        ["Feasibility index", "Λ", q("Lambda_hat", 2), "derived, eq. (13)"],
        ["Required instructional gain", "G*", q("gain_star", 2), "derived"],
        ["Anchoring gain", "log₁₀(τ_esc/T_lock)", q("log10_anchor_gain", 2),
         "derived, eq. (15)"],
        ["Participants with a locked state", "—",
         f"{100*d.locked.mean():.1f}%", "derived"],
        ["Participants below the coherence threshold", "—",
         f"{100*d.subcritical.mean():.1f}%", "derived"],
        ["Participants with Λ < 1", "—",
         f"{100*(d.Lambda_hat < 1).mean():.1f}%", "derived"],
    ]
    return hdr, rows


def table3():
    st = pd.read_csv(os.path.join(RES, "statistics.csv"))
    c = st[st.analysis == "categorical"]
    pretty = {"sync_R": "Assembly coherence ⟨R̄⟩", "meta_R": "Metastability SD[R̄]",
              "r_intra_raw": "Within-module coherence",
              "plv_bar": "Inter-module phase locking",
              "switch_per_min": "Switching rate",
              "cc_sync": "Triad coherence", "cc_meta": "Triad metastability",
              "cc_plv_bar": "Triad phase locking",
              "cc_switch_per_min": "Triad switching rate",
              "K_out_hat": "Assembly coupling K", "sigma_hat": "Phase noise σ",
              "K_in_hat": "Within-module coupling K_in",
              "dU_hat": "Barrier ΔU₊", "D_hat": "Noise intensity D",
              "Lambda_hat": "Feasibility index Λ",
              "tau_esc_hat_log10": "log₁₀ escape time"}
    hdr = ["Outcome", "n", "β (95% CI)", "Hedges' g (95% CI)", "P",
           "q (FDR)", "P (perm.)", "LOSO"]
    rows = []
    for r in c.itertuples():
        rows.append([
            pretty.get(r.outcome, r.outcome), f"{int(r.n)}",
            f"{r.beta_std:.3f} ({r.ci_lo:.3f} to {r.ci_hi:.3f})",
            f"{r.hedges_g:.3f} ({r.g_lo:.3f} to {r.g_hi:.3f})",
            f"{r.p:.3f}", f"{r.q_fdr:.3f}",
            "—" if not np.isfinite(r.p_perm) else f"{r.p_perm:.3f}",
            "yes" if r.loso_sign_consistent else "no"])
    return hdr, rows


def table4():
    t = pd.read_csv(os.path.join(RES, "surrogate_tests.csv"))
    pretty = {"sync_R": "Assembly coherence", "meta_R": "Metastability",
              "r_intra_raw": "Within-module coherence",
              "plv_bar": "Inter-module phase locking",
              "slip_rate_bar": "Phase-slip rate", "p_k_ge_4": "P(k ≥ 4)",
              "switch_per_min": "Switching rate", "cc_sync": "Triad coherence",
              "cc_meta": "Triad metastability", "cc_plv_bar": "Triad locking",
              "cc_switch_per_min": "Triad switching",
              "delta_emp": "Module frequency dispersion"}
    hdr = ["Observable", "Real (mean)", "Surrogate (mean)", "d_z", "P",
           "Group effect on excess (g)", "P"]
    rows = []
    for r in t.itertuples():
        n = 5 if abs(r.real_mean) < 0.02 else 3
        rows.append([pretty.get(r.observable, r.observable),
                     fmt(r.real_mean, n), fmt(r.surr_mean, n),
                     fmt(r.cohen_dz, 3), f"{r.p_vs_surrogate:.4f}",
                     fmt(r.excess_g, 3), f"{r.p_group_on_excess:.3f}"])
    return hdr, rows


def md_table(hdr, rows):
    out = ["| " + " | ".join(hdr) + " |",
           "|" + "|".join(["---"] * len(hdr)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(x) for x in r) + " |")
    return "\n".join(out)


def main():
    d = pd.read_csv(os.path.join(RES, "dynamics_qc.csv")).merge(
        pd.read_csv(os.path.join(RES, "latent_parameters.csv")), on="FILE_ID")
    blocks = []
    for name, (hdr, rows), cap in (
        ("Table 1", table1(d),
         "**Table 1. Participant characteristics.** Values are mean ± SD unless "
         "stated. P values are from Mann–Whitney U tests for continuous "
         "variables and a chi-squared test for sex. Full-scale IQ, framewise "
         "displacement and sex were included as covariates in all models."),
        ("Table 2", table2(d),
         "**Table 2. Model quantities estimated in the cohort (n = 477).** "
         "Inverted parameters come from the simulation-based inversion; derived "
         "quantities follow from the equations indicated. The frequency "
         "dispersion was fixed at a calibrated value because it was not "
         "identifiable from these observables."),
        ("Table 3", table3(),
         "**Table 3. Categorical contrasts between autistic and non-autistic "
         "participants.** β is the standardised group difference from a linear "
         "mixed model with site as a random intercept, adjusted for age, sex, "
         "full-scale IQ, mean framewise displacement, retained volumes and eye "
         "status. q values are Benjamini–Hochberg corrected within the "
         "observable and latent families. Permutation P values are from 4,000 "
         "site-stratified permutations. LOSO indicates whether the sign of β "
         "was preserved when each site was removed in turn. The lower n for "
         "barrier-dependent quantities reflects participants without a locked "
         "state."),
        ("Table 4", table4(),
         "**Table 4. Observables compared with each participant's own "
         "multivariate phase-randomised surrogates.** d_z is the standardised "
         "within-participant difference; P values are from Wilcoxon signed-rank "
         "tests. The final columns give the standardised group difference in "
         "the surrogate-corrected excess and its Mann–Whitney P value."),
    ):
        blocks.append(f"### {name}\n\n{cap}\n\n{md_table(hdr, rows)}\n")
    txt = "\n\n".join(blocks)
    with open(os.path.join(OUT, "tables.md"), "w") as fh:
        fh.write(txt)
    print(txt[:2600])


if __name__ == "__main__":
    main()
