"""
04_statistics.py — Confirmatory analysis of the ABN observables and of the
inverted latent parameters.

Analyses, in the order in which they are reported:

  (1) Categorical contrast.  Linear mixed models with acquisition site as a
      random intercept and age, sex, full-scale IQ, mean framewise
      displacement, number of retained volumes and eye status as fixed
      covariates.  Benjamini-Hochberg control across the nine pre-specified
      outcomes.  Effect sizes as bias-corrected Hedges' g.

  (2) Dimensional contrast.  Within the autistic group, association of each
      outcome with the ADI-R restricted/repetitive behaviour domain (domain C)
      total, the phenotype the theory concerns, adjusted for the same
      covariates.  Secondary: ADOS calibrated RRB and SRS.

  (3) Robustness.  Leave-one-site-out refitting and site-stratified
      permutation tests (10,000 permutations of the group label within site).

  (4) Equivalence framing.  For null contrasts, the 90% CI of the standardised
      effect is reported so that the result is interpretable as a bound rather
      than as an absence of evidence.
"""
from __future__ import annotations
import os
import sys
import warnings

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")

COV = ["AGE_AT_SCAN", "SEX", "FIQ", "func_mean_fd", "n_tp_used",
       "EYE_STATUS_AT_SCAN"]

PRIMARY = ["sync_R", "meta_R", "r_intra_raw", "plv_bar", "switch_per_min",
           "cc_sync", "cc_meta", "cc_plv_bar", "cc_switch_per_min"]

LATENT = ["K_out_hat", "sigma_hat", "K_in_hat", "dU_hat", "D_hat",
          "Lambda_hat", "tau_esc_hat_log10"]


# ---------------------------------------------------------------------------
def hedges_g(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    a, b = a[np.isfinite(a)], b[np.isfinite(b)]
    n1, n2 = len(a), len(b)
    if n1 < 2 or n2 < 2:
        return np.nan, (np.nan, np.nan)
    s = np.sqrt(((n1 - 1) * a.var(ddof=1) + (n2 - 1) * b.var(ddof=1)) / (n1 + n2 - 2))
    if s == 0:
        return np.nan, (np.nan, np.nan)
    d = (a.mean() - b.mean()) / s
    J = 1 - 3 / (4 * (n1 + n2) - 9)
    g = J * d
    se = np.sqrt((n1 + n2) / (n1 * n2) + g ** 2 / (2 * (n1 + n2 - 2)))
    return g, (g - 1.96 * se, g + 1.96 * se)


def bh_fdr(p):
    p = np.asarray(p, float)
    ok = np.isfinite(p)
    q = np.full_like(p, np.nan)
    pv = p[ok]
    n = len(pv)
    order = np.argsort(pv)
    ranked = pv[order] * n / (np.arange(n) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(ranked, 0, 1)
    q[ok] = out
    return q


def prep(df, extra=()):
    d = df.copy()
    d["SEX"] = (d.SEX == 1).astype(float)
    d["ASD"] = (d.group == "ASD").astype(float)
    cols = ["ASD", "SITE_ID"] + COV + list(extra)
    for c in COV:
        d[c] = pd.to_numeric(d[c], errors="coerce")
        d[c] = d[c].fillna(d[c].median())
    return d, cols


def lmm_contrast(d, outcome, predictor="ASD", covariates=COV):
    import statsmodels.formula.api as smf
    sub = d[[outcome, predictor, "SITE_ID"] + covariates].dropna()
    if sub[predictor].nunique() < 2 or len(sub) < 30:
        return None
    z = sub.copy()
    sd_out = z[outcome].std(ddof=1)
    z["_y"] = (z[outcome] - z[outcome].mean()) / sd_out
    for c in covariates:
        s = z[c].std(ddof=1)
        z[c] = (z[c] - z[c].mean()) / (s if s > 0 else 1.0)
    if predictor != "ASD":
        s = z[predictor].std(ddof=1)
        z["_x"] = (z[predictor] - z[predictor].mean()) / (s if s > 0 else 1.0)
    else:
        z["_x"] = z[predictor]
    f = "_y ~ _x + " + " + ".join(covariates)
    try:
        m = smf.mixedlm(f, z, groups=z["SITE_ID"]).fit(reml=True)
    except Exception:
        return None
    b = m.params["_x"]; se = m.bse["_x"]; p = m.pvalues["_x"]
    return {"outcome": outcome, "n": len(sub), "beta_std": b, "se": se,
            "p": p, "ci_lo": b - 1.96 * se, "ci_hi": b + 1.96 * se,
            "ci90_lo": b - 1.645 * se, "ci90_hi": b + 1.645 * se}


def perm_test_within_site(d, outcome, n_perm=10000, seed=7):
    """Site-stratified permutation test of the group difference in means."""
    sub = d[[outcome, "ASD", "SITE_ID"]].dropna()
    if len(sub) < 30:
        return np.nan
    rng = np.random.default_rng(seed)

    def stat(lbl):
        tot = 0.0
        for _, gg in sub.assign(L=lbl).groupby("SITE_ID"):
            a = gg.loc[gg.L == 1, outcome]
            b = gg.loc[gg.L == 0, outcome]
            if len(a) > 1 and len(b) > 1:
                tot += (a.mean() - b.mean()) * (len(a) + len(b))
        return tot / len(sub)

    obs = stat(sub.ASD.values)
    cnt = 0
    labels = sub.ASD.values.copy()
    site = sub.SITE_ID.values
    for _ in range(n_perm):
        pl = labels.copy()
        for s in np.unique(site):
            m = site == s
            pl[m] = rng.permutation(pl[m])
        if abs(stat(pl)) >= abs(obs):
            cnt += 1
    return (cnt + 1) / (n_perm + 1)


def leave_one_site_out(d, outcome, predictor="ASD"):
    betas = {}
    for s in sorted(d.SITE_ID.unique()):
        r = lmm_contrast(d[d.SITE_ID != s], outcome, predictor)
        if r:
            betas[s] = r["beta_std"]
    v = np.array(list(betas.values()))
    return {"loso_min": v.min(), "loso_max": v.max(),
            "loso_sign_consistent": bool(np.all(v > 0) or np.all(v < 0))}


# ---------------------------------------------------------------------------
def run(df, outcomes, label, predictor="ASD", do_perm=True, n_perm=4000):
    d, _ = prep(df)
    rows = []
    for o in outcomes:
        if o not in d.columns:
            continue
        r = lmm_contrast(d, o, predictor)
        if r is None:
            continue
        if predictor == "ASD":
            g, ci = hedges_g(d.loc[d.ASD == 1, o], d.loc[d.ASD == 0, o])
            r.update(hedges_g=g, g_lo=ci[0], g_hi=ci[1])
            r["mean_ASD"] = d.loc[d.ASD == 1, o].mean()
            r["mean_TD"] = d.loc[d.ASD == 0, o].mean()
        if do_perm and predictor == "ASD":
            r["p_perm"] = perm_test_within_site(d, o, n_perm=n_perm)
        r.update(leave_one_site_out(d, o, predictor))
        rows.append(r)
    out = pd.DataFrame(rows)
    if len(out):
        out["q_fdr"] = bh_fdr(out.p.values)
        out.insert(0, "analysis", label)
        out.insert(1, "predictor", predictor)
    return out


def main():
    d = pd.read_csv(os.path.join(RES, "dynamics_qc.csv"))
    inv = os.path.join(RES, "latent_parameters.csv")
    if os.path.exists(inv):
        lat = pd.read_csv(inv)
        d = d.merge(lat, on="FILE_ID", how="left")
    outcomes = [c for c in PRIMARY + LATENT if c in d.columns]

    print(f"N = {len(d)}  ({d.group.value_counts().to_dict()})")
    tables = []

    t1 = run(d, outcomes, "categorical", "ASD")
    tables.append(t1)
    print("\n=== (1) ASD vs TD, site-random-intercept LMM ===")
    print(t1[["outcome", "n", "beta_std", "ci_lo", "ci_hi", "p", "q_fdr",
              "hedges_g", "p_perm", "loso_sign_consistent"]]
          .round(4).to_string(index=False))

    asd = d[d.group == "ASD"]
    for dim, nm in (("ADI_RRB_TOTAL_C", "ADI-R domain C (RRB)"),
                    ("ADOS_GOTHAM_RRB", "ADOS calibrated RRB"),
                    ("ADI_R_SOCIAL_TOTAL_A", "ADI-R domain A (social)")):
        sub = asd[asd[dim].notna()]
        if len(sub) < 60:
            continue
        t = run(sub, outcomes, f"dimensional:{dim}", dim, do_perm=False)
        tables.append(t)
        print(f"\n=== (2) Within ASD: {nm}  (n={len(sub)}) ===")
        print(t[["outcome", "n", "beta_std", "ci_lo", "ci_hi", "p", "q_fdr",
                 "loso_sign_consistent"]].round(4).to_string(index=False))

    srs = d[d.SRS_RAW_TOTAL.notna()]
    if len(srs) > 80:
        t = run(srs, outcomes, "dimensional:SRS_all", "SRS_RAW_TOTAL",
                do_perm=False)
        tables.append(t)
        print(f"\n=== (2b) Whole sample: SRS total (n={len(srs)}) ===")
        print(t[["outcome", "n", "beta_std", "ci_lo", "ci_hi", "p", "q_fdr"]]
              .round(4).to_string(index=False))

    full = pd.concat(tables, ignore_index=True)
    full.to_csv(os.path.join(RES, "statistics.csv"), index=False)
    print("\nwritten results/statistics.csv")


if __name__ == "__main__":
    main()
