"""
07_protocols.py — Simulation of three instructional protocols in the
hierarchical Kuramoto model, at parameters taken from the empirical inversion.

The learning task is formalised as a prescribed reconfiguration of the
assembly.  A target module T starts phase-locked to a pre-existing, highly
coherent "prior-knowledge" module P (the entrenched association) and must
instead join the instructional assembly A, whose phase is set by the teaching
signal.  Success is defined as T spending at least SUCCESS_FRAC of the final
third of the session phase-aligned with A rather than with P, while the
assembly order parameter R over the instructional modules stays above
R_FLOOR -- that is, the new knowledge must be bound into an integrated
assembly, not merely detached from the old one.

Protocols
---------
  abrupt    The instructional drive is switched on at full strength at t=0 and
            the only route out of the prior attractor is stochastic: the noise
            is raised to sigma_protocol.  This is the formal counterpart of an
            unsignalled change of task demand.

  anchored  The instructional drive is coupled to the target through the prior
            module itself: the teaching content is delivered inside the
            pre-existing attractor, so that P acts as a phase reference that
            is gradually detuned towards the assembly phase.  Noise is left at
            its resting value.

  graduated The instructional coupling is ramped linearly from zero over the
            session at a rate below the critical sweep rate, with noise at its
            resting value.

Outputs: results/protocol_runs.csv, results/protocol_summary.csv
"""
from __future__ import annotations
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import wrap  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")

F0 = 0.055
SUCCESS_FRAC = 0.6
R_FLOOR = 0.30
ALIGN_WIN = np.pi / 3


def run_protocol(protocol, K_prior, K_instr, sigma_rest, sigma_protocol,
                 delta_b=0.006, n_per=(34, 21, 32, 33, 22), K_in=0.16,
                 T_sec=1800.0, dt=0.05, seed=0, ramp_frac=0.8):
    """Integrate one session. Modules: 0 = prior P, 1 = target T, 2..4 = assembly."""
    rng = np.random.default_rng(seed)
    n_per = np.asarray(n_per)
    M, n = len(n_per), int(n_per.sum())
    off = np.concatenate([[0], np.cumsum(n_per)])
    Ind = np.zeros((n, M))
    for m in range(M):
        Ind[off[m]:off[m + 1], m] = 1.0 / n_per[m]
    Expand = (Ind > 0).astype(float)

    om_mod = 2 * np.pi * (F0 + rng.normal(0, delta_b, M))
    omega = om_mod @ Expand.T + 2 * np.pi * rng.normal(0, 0.006, n)
    th = rng.uniform(-np.pi, np.pi, n)

    # burn-in: target locked to prior, strong K_prior between modules 0 and 1
    n_burn = int(300.0 / dt)
    n_steps = int(T_sec / dt)
    assembly = np.array([2, 3, 4])
    rec_t, rec_align_A, rec_align_P, rec_R = [], [], [], []

    for k in range(-n_burn, n_steps):
        t = k * dt
        e = np.exp(1j * th)
        zm = e @ Ind
        rm, psim = np.abs(zm), np.angle(zm)
        zA = np.exp(1j * psim[assembly]).mean()
        RA, psiA = np.abs(zA), np.angle(zA)

        drive = omega + K_in * (rm @ Expand.T) * np.sin((psim @ Expand.T) - th)
        # prior attractor: mutual locking of modules 0 and 1
        for (i, j) in ((0, 1), (1, 0)):
            sl = slice(off[i], off[i + 1])
            drive[sl] += K_prior * rm[j] * np.sin(psim[j] - th[sl])
        # assembly cohesion among modules 2-4
        for m in assembly:
            sl = slice(off[m], off[m + 1])
            drive[sl] += 0.08 * RA * np.sin(psiA - th[sl])

        sig = sigma_rest
        if k >= 0:
            if protocol == "abrupt":
                Kt = K_instr
                sig = sigma_protocol
                sl = slice(off[1], off[2])
                drive[sl] += Kt * RA * np.sin(psiA - th[sl])
            elif protocol == "graduated":
                Kt = K_instr * min(1.0, t / (ramp_frac * T_sec))
                sl = slice(off[1], off[2])
                drive[sl] += Kt * RA * np.sin(psiA - th[sl])
            elif protocol == "anchored":
                # the instructional signal is injected through the prior module,
                # whose phase is itself drawn towards the assembly
                Kt = K_instr
                sl0 = slice(off[0], off[1])
                drive[sl0] += Kt * RA * np.sin(psiA - th[sl0])
                sl1 = slice(off[1], off[2])
                drive[sl1] += Kt * rm[0] * np.sin(psim[0] - th[sl1])
            else:
                raise ValueError(protocol)

        th = th + drive * dt + sig * np.sqrt(dt) * rng.standard_normal(n)

        if k >= 0 and k % int(1.0 / dt) == 0:
            rec_t.append(t)
            rec_align_A.append(abs(wrap(psim[1] - psiA)) <= ALIGN_WIN)
            rec_align_P.append(abs(wrap(psim[1] - psim[0])) <= ALIGN_WIN)
            rec_R.append(RA)

    a_A = np.array(rec_align_A, float)
    a_P = np.array(rec_align_P, float)
    R = np.array(rec_R)
    last = slice(int(2 * len(a_A) / 3), None)
    frac_A = float(a_A[last].mean())
    frac_P = float(a_P[last].mean())
    R_mean = float(R[last].mean())
    success = bool(frac_A >= SUCCESS_FRAC and R_mean >= R_FLOOR)
    return dict(protocol=protocol, frac_aligned_assembly=frac_A,
                frac_aligned_prior=frac_P, R_assembly=R_mean,
                success=success, K_prior=K_prior, K_instr=K_instr,
                sigma_rest=sigma_rest, sigma_protocol=sigma_protocol)


def main(n_seeds=10, T_sec=1200.0, dt=0.08):
    rows = []
    sigma_rest = 0.80          # empirical median of the inversion
    for K_prior in (0.08, 0.16, 0.30, 0.50):
        for K_instr in (0.08, 0.16, 0.32, 0.64):
            for sp in (0.80, 1.60, 2.60, 4.00):
                for proto in ("abrupt", "anchored", "graduated"):
                    if proto != "abrupt" and sp != 1.60:
                        continue   # noise is manipulated only in the abrupt arm
                    for s in range(n_seeds):
                        r = run_protocol(proto, K_prior, K_instr, sigma_rest,
                                         sp, T_sec=T_sec, dt=dt,
                                         seed=1000 * s + int(1000 * K_prior)
                                         + int(100 * K_instr) + int(10 * sp))
                        r["seed"] = s
                        rows.append(r)
        print(f"  K_prior={K_prior} done", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "protocol_runs.csv"), index=False)

    summ = (df.groupby(["protocol", "K_prior", "K_instr", "sigma_protocol"])
            .agg(success_rate=("success", "mean"),
                 frac_A=("frac_aligned_assembly", "mean"),
                 frac_P=("frac_aligned_prior", "mean"),
                 R=("R_assembly", "mean"), n=("success", "size"))
            .reset_index())
    summ.to_csv(os.path.join(RES, "protocol_summary.csv"), index=False)
    pd.set_option("display.width", 200)
    print("\n=== success rate by protocol and prior-attractor strength ===")
    print(summ.pivot_table(index=["K_prior", "K_instr"], columns="protocol",
                           values="success_rate").round(3).to_string())
    print("\n=== assembly coherence retained ===")
    print(summ.pivot_table(index="protocol", columns="sigma_protocol",
                           values="R").round(3).to_string())
    print("\n=== overall ===")
    print(df.groupby("protocol")[["success", "frac_aligned_assembly",
                                  "frac_aligned_prior", "R_assembly"]]
          .mean().round(3).to_string())


if __name__ == "__main__":
    main()
