"""
05_invert.py — Simulation-based inversion of the hierarchical Kuramoto model.

Steps
-----
  1. Build a library of simulated observable vectors on a grid of
     (K_in, K_out, sigma), measured through the identical empirical pipeline
     at every (TR, number-of-volumes) design cell present in the cohort.
  2. Validate the inversion by parameter recovery: one simulation replicate is
     held out, treated as a set of pseudo-participants, and inverted against
     the library built from the remaining replicates.
  3. Invert every participant and derive the theory quantities:
         effective coupling      K_eff = K_out * Rbar      (measured Rbar)
         detuning                dOmega (measured per participant)
         noise intensity         D      = sigma^2 / 2
         barrier                 dU     = K_eff * B(a)
         escape time             tau_esc = tau_0 exp(dU/D)
         critical noise          D_c    = K_out/2 - delta
         escape noise            D_esc  = dU / log(T_session/tau_0)
         feasibility index       Lambda = D_c / D_esc

Outputs: results/library.csv, results/recovery.csv, results/latent_parameters.csv
"""
from __future__ import annotations
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import (CORTICAL_MODULES, OBS_KEYS, Lambda_gaussian,  # noqa: E402
                      barrier, critical_noise_gaussian, escape_noise,
                      escape_time, kramers_prefactor, required_coupling_gain,
                      entrainment_time)
from abn_model import N_PER, build_library, default_grid, invert  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")

T_SESSION = 1800.0        # s; nominal instructional session (sensitivity-tested)
N_REP = 3
T_SIM = 620.0
from abn_model import DELTA_B, OBS_NOISE, SHARED_DRIVE  # noqa: E402


def design_cells(d, min_n=5):
    """(TR, n_tp) cells present in the cohort; rare cells folded into the
    nearest cell with the same TR."""
    cnt = d.groupby(["TR", "n_tp_used"]).size().reset_index(name="n")
    big = cnt[cnt.n >= min_n]
    cells = [(float(r.TR), int(r.n_tp_used)) for r in big.itertuples()]

    def assign(row):
        same = [c for c in cells if abs(c[0] - row.TR) < 1e-6]
        pool = same if same else cells
        tr_c, n_c = min(pool, key=lambda c: (abs(c[0] - row.TR),
                                             abs(c[1] - row.n_tp_used)))
        return pd.Series({"TR_bin": tr_c, "n_tp_bin": n_c})

    d = d.join(d.apply(assign, axis=1))
    return d, cells


def main(obs_noise=OBS_NOISE, shared_drive=SHARED_DRIVE, tag="",
         delta_b=DELTA_B):
    d = pd.read_csv(os.path.join(RES, "dynamics_qc.csv"))
    d, cells = design_cells(d)
    print(f"N={len(d)}; {len(cells)} design cells:", cells)

    members = []
    off = np.concatenate([[0], np.cumsum(N_PER)])
    for i in range(len(N_PER)):
        members.append(np.arange(off[i], off[i + 1]))

    grid = default_grid()
    print(f"grid points: {len(grid)}; replicates: {N_REP}")
    lib = build_library(grid, [c[0] for c in cells], [c[1] for c in cells],
                        members, n_rep=N_REP, obs_noise=obs_noise,
                        shared_drive=shared_drive, T_sec=T_SIM,
                        delta_b=delta_b)
    lib["TR_bin"] = lib.TR
    lib["n_tp_bin"] = lib.n_tp
    lib.to_csv(os.path.join(RES, f"library{tag}.csv"), index=False)

    scales = {k: float(d[k].std(ddof=1)) for k in OBS_KEYS}
    print("observable scales:", {k: round(v, 5) for k, v in scales.items()})

    # ---- recovery validation -------------------------------------------
    held = lib[lib.rep == N_REP - 1].copy()
    train = lib[lib.rep < N_REP - 1].copy()
    rec = invert(held, train, scales)
    rec = pd.concat([held[["K_in", "K_out", "sigma", "TR_bin", "n_tp_bin"]]
                     .reset_index(drop=True), rec.reset_index(drop=True)], axis=1)
    rec.to_csv(os.path.join(RES, f"recovery{tag}.csv"), index=False)
    from scipy.stats import spearmanr
    print("\n=== recovery of latent parameters (held-out replicate) ===")
    for true, hat in (("K_out", "K_out_hat"), ("sigma", "sigma_hat"),
                      ("K_in", "K_in_hat")):
        rho, p = spearmanr(rec[true], rec[hat])
        rel = np.abs(rec[hat] - rec[true]) / rec[true]
        print(f"  {true:6s}: Spearman rho={rho:.3f} (p={p:.1e}); "
              f"median relative error={np.nanmedian(rel):.2f}")

    # ---- invert the participants ---------------------------------------
    res = invert(d, train, scales)
    out = pd.concat([d.reset_index(drop=True), res.reset_index(drop=True)],
                    axis=1)

    Rbar = out.sync_R.values
    K_out = out.K_out_hat.values
    sig = out.sigma_hat.values
    # frequency dispersion: fixed structural constant (see default_grid), in
    # rad/s, with the implied mean pairwise detuning E|w_i - w_j| = 2 s/sqrt(pi)
    s_rad = np.full(len(out), 2.0 * np.pi * delta_b)
    dOm = 2.0 * s_rad / np.sqrt(np.pi)

    K_eff = K_out * Rbar
    D = sig ** 2 / 2.0
    dU = np.array([barrier(k, w) for k, w in zip(K_eff, dOm)])
    tau0 = np.array([kramers_prefactor(k, w) for k, w in zip(K_eff, dOm)])
    tesc = np.array([escape_time(k, w, dd) for k, w, dd in zip(K_eff, dOm, D)])
    D_c = np.array([critical_noise_gaussian(k, ss) for k, ss in zip(K_out, s_rad)])
    D_esc = np.array([escape_noise(k, w, T_SESSION) for k, w in zip(K_eff, dOm)])
    lam = np.array([Lambda_gaussian(k, ss, rb, w, T_SESSION)
                    for k, ss, rb, w in zip(K_out, s_rad, Rbar, dOm)])
    gain = np.array([required_coupling_gain(k, ss, rb, w, T_SESSION)
                     for k, ss, rb, w in zip(K_out, s_rad, Rbar, dOm)])
    t_lock = np.array([entrainment_time(k, w) for k, w in zip(K_eff, dOm)])

    out["K_eff_hat"] = K_eff
    out["D_hat"] = D
    out["dU_hat"] = dU
    out["dU_over_D_hat"] = dU / D
    out["tau0_hat"] = tau0
    out["tau_esc_hat"] = tesc
    out["tau_esc_hat_log10"] = np.log10(np.clip(tesc, 1e-300, None))
    out["D_c_hat"] = D_c
    out["D_esc_hat"] = D_esc
    out["Lambda_hat"] = lam
    out["locked"] = np.isfinite(dU)
    out["sigma_c_hat"] = np.sqrt(np.clip(2 * D_c, 0, None))
    out["sigma_c_norm_hat"] = np.where(K_out > 0,
                                       np.sqrt(np.clip(2 * D_c, 0, None)
                                               / K_out), np.nan)
    out["s_rad_hat"] = s_rad
    out["dOmega_hat"] = dOm
    out["gain_star"] = gain
    out["log2_gain_star"] = np.log2(np.clip(gain, 1e-9, None))
    out["t_lock_hat"] = t_lock
    out["anchor_gain_hat"] = np.where(np.isfinite(tesc) & (t_lock > 0),
                                      tesc / t_lock, np.nan)
    out["log10_anchor_gain"] = np.log10(np.clip(out["anchor_gain_hat"], 1e-30, None))
    out["delta_over_K_hat"] = s_rad / K_out
    out["subcritical"] = D_c < 0

    keep = ["FILE_ID", "K_in_hat", "K_out_hat", "sigma_hat", "fit_dist", "K_eff_hat", "D_hat", "dU_hat", "dU_over_D_hat",
            "tau0_hat", "tau_esc_hat", "tau_esc_hat_log10", "D_c_hat",
            "D_esc_hat", "Lambda_hat", "locked", "sigma_c_hat",
            "sigma_c_norm_hat", "delta_over_K_hat", "s_rad_hat", "dOmega_hat",
            "gain_star", "log2_gain_star", "t_lock_hat", "anchor_gain_hat",
            "log10_anchor_gain", "subcritical", "TR_bin", "n_tp_bin"]
    out[keep].to_csv(os.path.join(RES, f"latent_parameters{tag}.csv"), index=False)

    print("\n=== inverted parameters by group ===")
    cols = ["K_in_hat", "K_out_hat", "sigma_hat", "K_eff_hat",
            "D_hat", "dU_hat", "dU_over_D_hat", "Lambda_hat", "gain_star",
            "log2_gain_star", "log10_anchor_gain", "delta_over_K_hat",
            "fit_dist"]
    print(out.groupby("group")[cols].median().round(4).T.to_string())
    print("\nfraction locked:", out.groupby("group").locked.mean().round(3).to_dict())
    print("fraction subcritical (D_c<0):",
          out.groupby("group").subcritical.mean().round(3).to_dict())
    print("fraction Lambda<1:",
          out.assign(inf=out.Lambda_hat < 1).groupby("group").inf.mean()
          .round(3).to_dict())
    print("\nfit distance quantiles:",
          np.nanpercentile(out.fit_dist, [50, 90, 99]).round(2))
    print("grid-edge hits: K_out at min %.3f / max %.3f"
          % ((out.K_out_hat == grid[:, 1].min()).mean(),
             (out.K_out_hat == grid[:, 1].max()).mean()))
    print("              sigma at min %.3f / max %.3f"
          % ((out.sigma_hat == grid[:, 2].min()).mean(),
             (out.sigma_hat == grid[:, 2].max()).mean()))


if __name__ == "__main__":
    on = float(sys.argv[1]) if len(sys.argv) > 1 else OBS_NOISE
    sd = float(sys.argv[2]) if len(sys.argv) > 2 else SHARED_DRIVE
    tg = sys.argv[3] if len(sys.argv) > 3 else ""
    db = float(sys.argv[4]) if len(sys.argv) > 4 else DELTA_B
    main(on, sd, tg, db)
