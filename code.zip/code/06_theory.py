"""
06_theory.py — Numerical verification of the ABN theorems.

Every closed-form result used in the manuscript is checked against direct
stochastic simulation of the model it describes.  Nothing is asserted that is
not reproduced here.

  A. Kramers law for escape from a phase-locked state.
     Prediction: tau_esc = [2 pi / (K sqrt(1-a^2))] exp(dU/D),
     dU = K [2 sqrt(1-a^2) - |a|(pi - 2 arcsin|a|)],  a = dOmega/K, D = sigma^2/2.

  B. Collapse of assembly coherence.
     Prediction: coherence requires K > K_c(D) = 2 / int g(w) D/(D^2+w^2) dw.
     Checked for a Gaussian frequency density at M = 5 and M = 60 modules, so
     that the finite-size smearing relevant to a five-network parcellation is
     quantified rather than assumed away.

  C. Feasibility theorem.
     Prediction: a noise level that both escapes the prior attractor within
     the session and sustains assembly coherence exists iff Lambda > 1, with
     Lambda = D_c / D_esc and D_esc = dU / log(T/tau_0).  The analytic
     Lambda = 1 contour is compared with the simulated feasible set.

  D. Anchoring theorem.
     Prediction: anchored entrainment time scales as (K_a^2 - dOmega^2)^(-1/2),
     algebraically in the control parameter, whereas noise-driven escape time
     scales as exp(dU/D).  The crossover and the gain are verified.

  E. Adiabatic protocol.
     Prediction: sweeping the detuning through the saddle-node at rate r
     delays unlocking by an amount scaling as r^(2/3).

  F. Consolidation.
     Correction cost after a period of structural consolidation.

Outputs: results/theory_*.csv
"""
from __future__ import annotations
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import (barrier, consolidated_coupling,  # noqa: E402
                      critical_coupling_gaussian, critical_noise_gaussian,
                      entrainment_time, escape_noise, escape_time,
                      kramers_prefactor, wrap)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)


# ---------------------------------------------------------------------------
# A. Kramers law for phase-slip escape
# ---------------------------------------------------------------------------
def mfpt_simulate(K, dOmega, sigma, n_trials=1500, dt=None, horizon_mult=3.0,
                  seed=0, max_steps=1_200_000):
    """Mean first-passage time out of the locked state, by censored MLE.

    Trials are integrated for a horizon of horizon_mult * tau_predicted.  For
    an exponentially distributed first-passage time the maximum-likelihood
    estimator of the mean given right-censoring is the total observation time
    divided by the number of observed escapes, which is unbiased and needs far
    less computation than running every trial to completion.
    """
    a = dOmega / K
    if abs(a) >= 1:
        return np.nan, 0.0
    phi_star = np.arcsin(a)
    fwd = np.pi - phi_star
    bwd = -np.pi - phi_star
    tau_pred = kramers_prefactor(K, dOmega) * np.exp(
        barrier(K, dOmega) / (sigma ** 2 / 2))
    dt = dt or 0.02 / K
    t_max = horizon_mult * tau_pred
    n_steps = int(min(t_max / dt, max_steps))
    t_max = n_steps * dt
    rng = np.random.default_rng(seed)
    phi = np.full(n_trials, phi_star)
    alive = np.ones(n_trials, bool)
    tfirst = np.full(n_trials, np.nan)
    sq = sigma * np.sqrt(dt)
    for k in range(n_steps):
        phi = np.where(alive,
                       phi + (dOmega - K * np.sin(phi)) * dt
                       + sq * rng.standard_normal(n_trials), phi)
        esc = alive & ((phi > fwd) | (phi < bwd))
        if esc.any():
            tfirst[esc] = (k + 1) * dt
            alive[esc] = False
        if not alive.any():
            break
    n_esc = int(np.isfinite(tfirst).sum())
    if n_esc == 0:
        return np.nan, 0.0
    total_time = np.nansum(tfirst) + alive.sum() * t_max
    return float(total_time / n_esc), float(n_esc / n_trials)


def part_A(seed=0):
    rows = []
    for K in (0.05, 0.12):
        for a in (0.0, 0.3, 0.6):
            dOm = a * K
            dU = barrier(K, dOm)
            for ratio in (1.5, 2.5, 3.5, 5.0):       # dU / D
                D = dU / ratio
                sigma = np.sqrt(2 * D)
                tau_pred = escape_time(K, dOm, D)
                tau_sim, frac = mfpt_simulate(K, dOm, sigma, n_trials=1500,
                                              seed=seed + int(1e4 * K + 100 * a
                                                              + ratio))
                rows.append(dict(K=K, a=a, dU=dU, dU_over_D=ratio, D=D,
                                 sigma=sigma, tau_pred=tau_pred,
                                 tau_sim=tau_sim, frac_escaped=frac,
                                 ratio_sim_pred=tau_sim / tau_pred))
                print(f"  A: K={K} a={a} dU/D={ratio}: pred={tau_pred:.1f}s "
                      f"sim={tau_sim:.1f}s  ratio={tau_sim/tau_pred:.3f}",
                      flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "theory_A_kramers.csv"), index=False)
    ok = df[df.dU_over_D >= 2.5]
    print(f"\n  A summary: median sim/pred = {df.ratio_sim_pred.median():.3f}; "
          f"for dU/D >= 2.5, median = {ok.ratio_sim_pred.median():.3f} "
          f"(range {ok.ratio_sim_pred.min():.2f}-{ok.ratio_sim_pred.max():.2f})")
    return df


# ---------------------------------------------------------------------------
# B. Coherence collapse and finite-size smearing
# ---------------------------------------------------------------------------
def kuramoto_meanfield(K, s_rad, D, M, T=2400.0, dt=0.1, seed=0, burn=0.25):
    rng = np.random.default_rng(seed)
    om = rng.normal(0.0, s_rad, M)
    th = rng.uniform(-np.pi, np.pi, M)
    n = int(T / dt)
    n_burn = int(burn * n)
    sq = np.sqrt(2 * D * dt)
    acc = []
    for k in range(n):
        z = np.exp(1j * th).mean()
        th = th + (om + K * np.abs(z) * np.sin(np.angle(z) - th)) * dt \
            + sq * rng.standard_normal(M)
        if k >= n_burn:
            acc.append(abs(z))
    return float(np.mean(acc))


def part_B():
    rows = []
    s_rad = 2 * np.pi * 0.006
    for M in (5, 60):
        for K_mult in (0.4, 0.7, 1.0, 1.3, 1.8, 2.6, 4.0):
            for D in (0.002, 0.01, 0.04, 0.10):
                Kc = critical_coupling_gaussian(D, s_rad)
                K = K_mult * Kc
                R = kuramoto_meanfield(K, s_rad, D, M, seed=M * 7 + int(1e4 * D))
                rows.append(dict(M=M, D=D, K=K, K_over_Kc=K_mult, Kc=Kc, R=R))
        print(f"  B: M={M} done", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "theory_B_collapse.csv"), index=False)
    piv = df.pivot_table(index="K_over_Kc", columns="M", values="R",
                         aggfunc="mean")
    print("\n  B: mean R versus K/K_c\n", piv.round(3).to_string())
    print("  finite-size floor at K/K_c=0.4:",
          piv.loc[0.4].round(3).to_dict())
    return df


# ---------------------------------------------------------------------------
# C. Feasibility theorem
# ---------------------------------------------------------------------------
def part_C(T_session=1800.0):
    s_rad = 2 * np.pi * 0.006
    rows = []
    for K in np.geomspace(0.03, 1.2, 26):
        for Rbar in (0.5, 0.6, 0.75, 0.9):
            dOm = 2 * s_rad / np.sqrt(np.pi)
            K_eff = K * Rbar
            dU = barrier(K_eff, dOm)
            D_c = critical_noise_gaussian(K, s_rad)
            D_esc = escape_noise(K_eff, dOm, T_session)
            lam = D_c / D_esc if (np.isfinite(D_esc) and D_esc > 0) else np.nan
            rows.append(dict(K=K, Rbar=Rbar, K_eff=K_eff, dU=dU, D_c=D_c,
                             D_esc=D_esc, Lambda=lam))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "theory_C_feasibility.csv"), index=False)

    # simulated check at a few points: does a noise level satisfy both?
    checks = []
    for K, Rbar in ((0.08, 0.6), (0.20, 0.6), (0.60, 0.6), (0.20, 0.9)):
        dOm = 2 * s_rad / np.sqrt(np.pi)
        K_eff = K * Rbar
        D_c = critical_noise_gaussian(K, s_rad)
        D_esc = escape_noise(K_eff, dOm, T_session)
        lam = D_c / D_esc if (np.isfinite(D_esc) and D_esc > 0) else np.nan
        feasible_sim = False
        best = None
        for D in np.geomspace(max(D_esc, 1e-5) * 0.25,
                              max(D_esc, 1e-5) * 6, 9):
            tau, _ = mfpt_simulate(K_eff, dOm, np.sqrt(2 * D), n_trials=400,
                                   seed=int(1e5 * K + 10 * Rbar))
            R = kuramoto_meanfield(K, s_rad, D, 60, T=2500.0,
                                   seed=int(1e4 * D) + 3)
            escaped = np.isfinite(tau) and tau <= T_session
            coherent = R > 0.25
            if escaped and coherent:
                feasible_sim = True
                best = (D, tau, R)
                break
        checks.append(dict(K=K, Rbar=Rbar, Lambda=lam,
                           feasible_analytic=bool(np.isfinite(lam) and lam > 1),
                           feasible_sim=feasible_sim,
                           witness=str(best)))
        print(f"  C: K={K} Rbar={Rbar}: Lambda={lam:.2f} "
              f"analytic={np.isfinite(lam) and lam>1} sim={feasible_sim}",
              flush=True)
    pd.DataFrame(checks).to_csv(os.path.join(RES, "theory_C_checks.csv"),
                                index=False)
    return df


# ---------------------------------------------------------------------------
# D. Anchoring theorem
# ---------------------------------------------------------------------------
def part_D():
    s_rad = 2 * np.pi * 0.006
    dOm = 2 * s_rad / np.sqrt(np.pi)
    rows = []
    for K_eff in np.geomspace(0.03, 1.0, 22):
        dU = barrier(K_eff, dOm)
        for D in (0.05, 0.15, 0.45):
            t_esc = escape_time(K_eff, dOm, D)
            for K_a_mult in (1.5, 3.0, 8.0):
                K_a = K_a_mult * abs(dOm)
                t_lock = entrainment_time(K_a, dOm)
                rows.append(dict(K_eff=K_eff, dU=dU, D=D, K_a=K_a,
                                 K_a_over_dOmega=K_a_mult, tau_esc=t_esc,
                                 t_lock=t_lock, gain=t_esc / t_lock))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "theory_D_anchoring.csv"), index=False)

    # scaling check of the entrainment time
    sc = []
    for K_a in np.geomspace(1.02 * abs(dOm), 50 * abs(dOm), 24):
        t = entrainment_time(K_a, dOm)
        sc.append(dict(K_a=K_a, t_lock=t,
                       pred=np.pi / np.sqrt(K_a ** 2 - dOm ** 2)))
    sc = pd.DataFrame(sc)
    sc["ratio"] = sc.t_lock / sc.pred
    sc.to_csv(os.path.join(RES, "theory_D_scaling.csv"), index=False)
    lg = np.polyfit(np.log(sc.K_a[sc.K_a > 4 * abs(dOm)]),
                    np.log(sc.t_lock[sc.K_a > 4 * abs(dOm)]), 1)[0]
    print(f"\n  D: log-log slope of t_lock vs K_a (K_a >> dOmega) = {lg:.3f} "
          f"(theory -1)")
    print(f"  D: gain at K_eff=0.5, D=0.15, K_a/dOmega=3: "
          f"{df[(np.isclose(df.D,0.15))&(df.K_a_over_dOmega==3.0)].gain.max():.3g}")
    return df


# ---------------------------------------------------------------------------
# E. Adiabatic sweep through the saddle-node
# ---------------------------------------------------------------------------
def sweep_unlock(K, dOm0, rate, dt=0.01, seed=0, sigma=0.0):
    """Ramp the detuning upward at `rate`; return the detuning at unlocking."""
    rng = np.random.default_rng(seed)
    phi = np.arcsin(np.clip(dOm0 / K, -1, 1))
    dOm = dOm0
    t = 0.0
    while dOm < 3.0 * K:
        dOm = dOm0 + rate * t
        phi = phi + (dOm - K * np.sin(phi)) * dt
        if sigma > 0:
            phi += sigma * np.sqrt(dt) * rng.standard_normal()
        t += dt
        if phi > np.pi / 2 + 1.0:            # left the locked branch
            return dOm
    return np.nan


def part_E():
    K = 0.2
    rows = []
    for rate in np.geomspace(1e-6, 1e-3, 10):
        dOm_unlock = sweep_unlock(K, 0.2 * K, rate, dt=0.005)
        delay = dOm_unlock - K
        rows.append(dict(rate=rate, dOmega_unlock=dOm_unlock, delay=delay,
                         pred=2.946 * (rate ** 2 / K) ** (1 / 3)))
    df = pd.DataFrame(rows)
    df["ratio"] = df.delay / df.pred
    df.to_csv(os.path.join(RES, "theory_E_sweep.csv"), index=False)
    slope = np.polyfit(np.log(df.rate), np.log(df.delay), 1)[0]
    print(f"\n  E: log-log slope of unlocking delay vs sweep rate = "
          f"{slope:.3f} (theory 2/3 = 0.667); median ratio to prediction = "
          f"{df.ratio.median():.3f}")
    return df


# ---------------------------------------------------------------------------
# F. Consolidation and the correction window
# ---------------------------------------------------------------------------
def part_F(T_session=1800.0):
    s_rad = 2 * np.pi * 0.006
    dOm = 2 * s_rad / np.sqrt(np.pi)
    rows = []
    for tau_c_days in (1.0, 7.0, 30.0):
        for t_days in np.geomspace(0.05, 180.0, 40):
            K_eff = consolidated_coupling(t_days, 0.6, tau_c_days)
            if K_eff <= abs(dOm):
                continue
            dU = barrier(K_eff, dOm)
            D = 0.15
            rows.append(dict(tau_c_days=tau_c_days, t_days=t_days,
                             K_eff=K_eff, dU=dU,
                             tau_esc_s=escape_time(K_eff, dOm, D),
                             D_esc=escape_noise(K_eff, dOm, T_session),
                             t_lock_s=entrainment_time(3 * abs(dOm), dOm)))
    df = pd.DataFrame(rows)
    df["log10_cost_ratio"] = np.log10(df.tau_esc_s / df.t_lock_s)
    df.to_csv(os.path.join(RES, "theory_F_consolidation.csv"), index=False)
    sub = df[df.tau_c_days == 7.0]
    print("\n  F: with tau_c = 7 d, escape time rises from "
          f"{sub.tau_esc_s.iloc[0]:.1f} s at t={sub.t_days.iloc[0]:.2f} d to "
          f"{sub.tau_esc_s.iloc[-1]:.3g} s at t={sub.t_days.iloc[-1]:.0f} d")
    return df


PARTS = {"A": part_A, "B": part_B, "C": part_C, "D": part_D, "E": part_E,
         "F": part_F}

if __name__ == "__main__":
    which = sys.argv[1:] if len(sys.argv) > 1 else list(PARTS)
    for w in which:
        print(f"\n=== part {w} ===", flush=True)
        PARTS[w]()
    print("\ntheory checks written to results/")
