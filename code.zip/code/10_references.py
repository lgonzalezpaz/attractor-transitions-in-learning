"""
10_references.py — Build the reference list from registered Crossref metadata.

Every reference cited in the manuscript is listed here by DOI only.  The
script retrieves the registered metadata for each DOI and formats it in
Vancouver/Nature style, so that author lists, titles, journal abbreviations,
years, volumes and pages are taken from the registry rather than transcribed
by hand.  Any DOI that fails to resolve is reported and must be corrected
before submission.
"""
from __future__ import annotations
import json
import os
import sys
import time

import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "manuscript")

# Ordered by first appearance in the manuscript.
DOIS = [
    "10.1001/jama.2022.23661",                      # 1  Hirota & King 2023
    "10.1016/S1474-4422(20)30034-X",                # 2  Lai 2020
    "10.1038/s41467-021-23822-5",                   # 3  Supekar 2021
    "10.1038/ncomms16048",                          # 4  Watanabe & Rees 2017
    "10.1523/ENEURO.0146-23.2023",                  # 5  Watanabe & Watanabe 2023
    "10.1038/s41593-025-01961-y",                   # 6  Watanabe & Yamasue 2025
    "10.1007/978-3-030-18830-6_13",                 # 7  Duch 2019
    "10.1016/j.bpsgos.2026.100787",                 # 8  Fuhr 2026
    "10.1177/1362361320932437",                     # 9  Jenkinson 2020
    "10.1007/s10803-013-2001-x",                    # 10 Boulter 2014
    "10.1007/s10803-014-2248-x",                    # 11 Wigham 2015
    "10.3102/0034654315604027",                     # 12 Gunn & Delafield-Butt 2016
    "10.1007/s10803-013-1765-3",                    # 13 Koegel 2013
    "10.1177/13623613231159699",                    # 14 Wright 2023 I-SOCIALISE
    "10.1016/j.cpr.2013.07.005",                    # 15 Virues-Ortega 2013
    "10.12669/pjms.41.9.12634",                     # 16 Zhu 2025
    "10.1177/1362361319836371",                     # 17 Tiede & Walton 2019
    "10.1136/bmj-2023-076733",                      # 18 Sandbank 2023
    "10.1007/s40616-019-00124-y",                   # 19 Leaf 2020
    "10.1016/j.ridd.2019.103521",                   # 20 Markham 2020
    "10.1098/rsta.2016.0287",                       # 21 Ezaki 2017
    "10.1371/journal.pcbi.1011446",                 # 22 Ye, Feng & Li 2023
    "10.1038/ncomms9414",                           # 23 Gu 2015
    "10.1038/nphys4268",                            # 24 Kim 2018
    "10.1088/1741-2552/ab6e8b",                     # 25 Karrer 2020
    "10.1371/journal.pcbi.1000587",                 # 26 Deco 2009
    "10.1103/PhysRevE.92.050903",                   # 27 Defoort 2015
    "10.1016/S0031-8914(40)90098-2",                # 28 Kramers 1940
    "10.1103/RevModPhys.62.251",                    # 29 Hanggi 1990
    "10.1137/17M1126412",                           # 30 Creaser 2018
    "10.1007/BF01029202",                           # 31 Strogatz & Mirollo 1991
    "10.1143/PTP.79.39",                            # 32 Sakaguchi 1988
    "10.1103/RevModPhys.77.137",                    # 33 Acebron 2005
    "10.1007/1-84628-186-5",                        # 34 Berglund & Gentz 2006
    "10.1088/1361-6544/ae7ec0",                     # 35 Bergeot 2026
    "10.1038/mp.2013.78",                           # 36 Di Martino 2014
    "10.3389/conf.fninf.2013.09.00041",             # 37 Craddock 2013 (PCP)
    "10.1016/j.neuroimage.2011.10.018",             # 38 Power 2012
    "10.1016/j.neuroimage.2013.08.048",             # 39 Power 2014
    "10.1016/j.neuroimage.2017.03.020",             # 40 Ciric 2017
    "10.1126/science.1194144",                      # 41 Dosenbach 2010
    "10.1089/brain.2011.0068",                      # 42 Glerean 2012
    "10.1109/PROC.1963.2308",                       # 43 Bedrosian 1963
    "10.1049/ji-3-2.1946.0074",                     # 44 Gabor 1946
    "10.1063/1.3305451",                            # 45 Shanahan 2010
    "10.1063/1.4766592",                            # 46 Wildie & Shanahan 2012
    "10.1038/s41598-017-03073-5",                   # 47 Deco 2017
    "10.3389/fncir.2025.1500227",                   # 48 Hosaka 2025
    "10.1016/j.neuroimage.2015.11.055",             # 49 Hindriks 2016
    "10.1016/j.neuroimage.2017.09.012",             # 50 Liegeois 2017
    "10.1073/pnas.1400181111",                      # 51 Zalesky 2014
    "10.1103/PhysRevLett.73.951",                   # 52 Prichard & Theiler 1994
    "10.1016/0167-2789(92)90102-S",                 # 53 Theiler 1992
    "10.2307/2529876",                              # 54 Laird & Ware 1982
    "10.1111/j.2517-6161.1995.tb02031.x",           # 55 Benjamini & Hochberg 1995
    "10.3102/10769986006002107",                    # 56 Hedges 1981
    "10.1002/hbm.1058",                             # 57 Nichols & Holmes 2002
    "10.1177/1948550617697177",                     # 58 Lakens 2017
    "10.1093/cercor/bhw265",                        # 59 Laumann 2017
    "10.1038/s41551-023-01117-y",                   # 60 Nozari 2024
    "10.3390/bioengineering11090882",               # 61 Zhang 2024
    "10.1002/aur.2488",                             # 62 Kupis 2021
    "10.1016/j.nicl.2019.101966",                   # 63 Rabany 2019
    "10.1038/s41586-022-04492-9",                   # 64 Marek 2022
    "10.1016/j.neuroimage.2013.05.099",             # 65 Birn 2013
    "10.1523/JNEUROSCI.0448-13.2013",               # 66 Robertson 2013
    "10.1016/j.cub.2019.07.026",                    # 67 Spiegel 2019
    "10.7554/eLife.42256",                          # 68 Watanabe 2019
]

MAILTO = "reference-check@example.org"

# Manual corrections where the registered metadata is incomplete. Each entry
# was checked against the publisher record; nothing here is invented.
OVERRIDES = {
    "10.1001/jama.2022.23661": {
        "title": "Autism spectrum disorder: a review", "page": "157-168"},
    "10.1038/ncomms16048": {"page": "16048"},
    "10.1007/978-3-030-18830-6_13": {
        "container": "Multiscale models of brain disorders",
        "page": "135-146", "publisher": "Springer"},
    "10.1093/cercor/bhw265": {
        "year": 2017, "volume": "27", "issue": "9", "page": "4719-4732"},
    "10.7554/eLife.42256": {"page": "e42256"},
    "10.1038/s41467-021-23822-5": {"page": "3537"},
    "10.3389/conf.fninf.2013.09.00041": {
        "note": "conference abstract; the citation prescribed by the "
                "Preprocessed Connectomes Project"},
}


def fetch(doi):
    url = f"https://api.crossref.org/works/{doi}"
    for attempt in range(4):
        try:
            r = requests.get(url, timeout=45,
                             headers={"User-Agent": f"abn-refs (mailto:{MAILTO})"})
            if r.status_code == 200:
                return r.json()["message"]
            if r.status_code == 404:
                return None
        except Exception:
            pass
        time.sleep(2 * (attempt + 1))
    return "ERROR"


def authors(msg, max_n=6):
    au = msg.get("author") or []
    out = []
    for a in au:
        fam = a.get("family")
        if not fam:
            if a.get("name"):
                out.append(a["name"])
            continue
        giv = a.get("given", "")
        ini = "".join(p[0] for p in giv.replace("-", " ").split() if p)
        out.append(f"{fam} {ini}".strip())
    if not out:
        return "[no author listed]"
    if len(out) > max_n:
        return ", ".join(out[:max_n]) + ", et al"
    return ", ".join(out)


def year(msg):
    for k in ("published-print", "published-online", "issued", "created"):
        v = msg.get(k)
        if v and v.get("date-parts") and v["date-parts"][0][0]:
            return v["date-parts"][0][0]
    return "n.d."


def container(msg):
    cs = msg.get("short-container-title") or []
    cl = msg.get("container-title") or []
    name = (cs[0] if cs else (cl[0] if cl else ""))
    return name.replace(".", "")


def format_ref(i, doi, msg):
    if msg is None or msg == "ERROR":
        return f"{i}. [UNRESOLVED DOI — verify before submission] doi:{doi}"
    ov = OVERRIDES.get(doi, {})
    title = ov.get("title") or (msg.get("title") or ["[no title]"])[0].strip().rstrip(".")
    au = authors(msg)
    yr = ov.get("year", year(msg))
    typ = msg.get("type", "")
    cont = ov.get("container", container(msg))
    vol = ov.get("volume", msg.get("volume", ""))
    iss = ov.get("issue", msg.get("issue", ""))
    pg = ov.get("page", msg.get("page", ""))
    if typ in ("book", "monograph", "edited-book"):
        pub = msg.get("publisher", "")
        return f"{i}. {au}. {title}. {pub}; {yr}. doi:{doi}"
    if typ == "book-chapter":
        bt = ov.get("container") or (msg.get("container-title") or [""])[0]
        pub = ov.get("publisher", msg.get("publisher", ""))
        tail = f" p. {pg}." if pg else ""
        return (f"{i}. {au}. {title}. In: {bt}. {pub}; {yr}.{tail} doi:{doi}")
    bits = f"{i}. {au}. {title}. {cont}. {yr}"
    if vol:
        bits += f";{vol}"
        if iss:
            bits += f"({iss})"
        if pg:
            bits += f":{pg}"
    elif pg:
        bits += f":{pg}"
    return bits + f". doi:{doi}"


def main():
    lines, problems, meta = [], [], []
    for i, doi in enumerate(DOIS, 1):
        msg = fetch(doi)
        if msg is None or msg == "ERROR":
            problems.append((i, doi, "unresolved" if msg is None else "error"))
        else:
            meta.append({"n": i, "doi": doi, "title": (msg.get("title") or [""])[0],
                         "type": msg.get("type"), "year": year(msg),
                         "container": container(msg)})
        lines.append(format_ref(i, doi, msg))
        print(lines[-1][:160], flush=True)
    with open(os.path.join(OUT, "references.md"), "w") as fh:
        fh.write("\n\n".join(lines) + "\n")
    with open(os.path.join(OUT, "references_meta.json"), "w") as fh:
        json.dump(meta, fh, indent=1)
    print(f"\n{len(DOIS)} references written; {len(problems)} problems")
    for p in problems:
        print("  PROBLEM:", p)


if __name__ == "__main__":
    main()
