"""
03_estimator_validation.py — Ground-truth validation of the ABN estimators.

Two independent synthetic benchmarks, both run before the estimators are
applied to any empirical data.

VALIDATION A — recovery of latent Adler parameters under finite-size noise.
  A latent phase difference is generated from
      dphi = (dOmega - K sin phi) dt + sqrt(2 D) dW
  and observed twice, with independent additive errors of the magnitude
  expected from averaging N regions at coherence r.  The naive and the
  split-half instrumental-variable estimators are compared with the truth.

VALIDATION B — full forward model.
  Five modules of N phase oscillators with known inter-module coupling are
  integrated, rendered as region-level signals, band-passed in 0.04-0.07 Hz,
  Hilbert-transformed, and passed through exactly the empirical pipeline, to
  verify that the recovered coupling tracks the true coupling monotonically
  and that group-level contrasts in true coupling are detected.

Outputs: results/validation_A.csv, results/validation_B.csv
"""
from __future__ import annotations
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import (CORTICAL_MODULES, analytic_phase, bandpass, debias_r,  # noqa: E402
                      fit_washboard_iv, module_order, wrap, washboard_barrier,
                      _halves, _z)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)


# ---------------------------------------------------------------------------
# Validation A
# ---------------------------------------------------------------------------
def latent_adler(dOmega, K, D, T, dt, rng):
    phi = np.zeros(T)
    for t in range(1, T):
        phi[t] = phi[t - 1] + (dOmega - K * np.sin(phi[t - 1])) * dt \
            + np.sqrt(2 * D * dt) * rng.normal()
    return wrap(phi)


def finite_size_sd(n, r):
    """SD of the error of a module mean phase built from n regions at coherence r."""
    return float(np.sqrt((1.0 - r ** 2) / (2.0 * n * r ** 2)))


def validation_A(n_rep=60, T=600, dt=2.0, seed=11):
    rng = np.random.default_rng(seed)
    rows = []
    grid = [(0.02, 0.05, 0.0020), (0.05, 0.12, 0.0040),
            (0.03, 0.20, 0.0080), (0.08, 0.30, 0.0150)]
    for (dOm, K, D) in grid:
        for n_roi, r_true in ((32, 0.30), (32, 0.45), (22, 0.30)):
            eps = finite_size_sd(n_roi, r_true)
            for rep in range(n_rep):
                phi = latent_adler(dOm, K, D, T, dt, rng)
                # two independent observations of the same latent difference
                fa = wrap(phi + eps * rng.normal(size=T) * np.sqrt(2))
                fb = wrap(phi + eps * rng.normal(size=T) * np.sqrt(2))
                f = fit_washboard_iv(fa, fb, dt, lag=1)
                rows.append(dict(dOmega_true=dOm, K_true=K, D_true=D,
                                 n_roi=n_roi, r_true=r_true, rep=rep,
                                 K_iv=f["K"], K_naive=f["K_naive"],
                                 D_iv=f["D"], D_naive=f["D_naive"],
                                 dOmega_hat=f["dOmega"]))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "validation_A.csv"), index=False)

    g = df.groupby(["K_true", "D_true", "n_roi", "r_true"]).agg(
        K_iv=("K_iv", "mean"), K_naive=("K_naive", "mean"),
        D_iv=("D_iv", "mean"), D_naive=("D_naive", "mean")).reset_index()
    g["K_bias_iv_pct"] = 100 * (g.K_iv - g.K_true) / g.K_true
    g["K_bias_naive_pct"] = 100 * (g.K_naive - g.K_true) / g.K_true
    g["D_bias_iv_pct"] = 100 * (g.D_iv - g.D_true) / g.D_true
    g["D_bias_naive_pct"] = 100 * (g.D_naive - g.D_true) / g.D_true
    print("\n=== VALIDATION A: latent-parameter recovery ===")
    print(g[["K_true", "D_true", "n_roi", "r_true", "K_bias_iv_pct",
             "K_bias_naive_pct", "D_bias_iv_pct", "D_bias_naive_pct"]]
          .round(1).to_string(index=False))
    print("\nmedian |bias| K: IV %.1f%%  naive %.1f%%"
          % (g.K_bias_iv_pct.abs().median(), g.K_bias_naive_pct.abs().median()))
    print("median |bias| D: IV %.1f%%  naive %.1f%%"
          % (g.D_bias_iv_pct.abs().median(), g.D_bias_naive_pct.abs().median()))
    g.to_csv(os.path.join(RES, "validation_A_summary.csv"), index=False)
    return g


# ---------------------------------------------------------------------------
# Validation B — full forward model
# ---------------------------------------------------------------------------
def forward_simulate(K_out, n_per=(34, 21, 32, 33, 22), K_in=0.55,
                     omega0=0.055, spread_within=0.004, spread_between=0.004,
                     sigma=0.45, T_sec=300.0, dt=0.1, tr=2.0, obs_noise=1.0,
                     seed=0):
    """Hierarchical Kuramoto -> region signals -> empirical pipeline input."""
    rng = np.random.default_rng(seed)
    M = len(n_per)
    nt = int(T_sec / dt)
    w0 = 2 * np.pi * omega0
    om_mod = w0 + 2 * np.pi * rng.normal(0, spread_between, M)
    th = [rng.uniform(-np.pi, np.pi, n) for n in n_per]
    om = [om_mod[m] + 2 * np.pi * rng.normal(0, spread_within, n_per[m])
          for m in range(M)]
    keep = max(1, int(round(tr / dt)))
    rec = []
    for t in range(nt):
        z = np.array([np.exp(1j * th[m]).mean() for m in range(M)])
        r, psi = np.abs(z), np.angle(z)
        zbar_psi = np.angle(np.exp(1j * psi).mean())
        rbar = np.abs(np.exp(1j * psi).mean())
        for m in range(M):
            d = om[m] + K_in * r[m] * np.sin(psi[m] - th[m]) \
                + K_out * rbar * np.sin(zbar_psi - th[m])
            th[m] = th[m] + d * dt + sigma * np.sqrt(dt) * rng.normal(size=n_per[m])
        if t % keep == 0:
            rec.append(np.concatenate([np.cos(th[m]) for m in range(M)]))
    X = np.array(rec)
    X = X + obs_noise * rng.normal(size=X.shape)
    return X


def run_pipeline(X, tr, members, n_splits=16, seed=3):
    x = (X - X.mean(0)) / X.std(0)
    xf = bandpass(x, tr)
    edge = int(np.ceil(25.0 / tr))
    if 2 * edge < xf.shape[0] - 20:
        xf = xf[edge:-edge]
    ph = analytic_phase(xf)
    r, psi = module_order(ph, members)
    M = psi.shape[1]
    rng = np.random.default_rng(seed)
    Ks, Ds, dOs, Kn = [], [], [], []
    for _ in range(n_splits):
        hv = [_halves(ix, rng) for ix in members]
        pa = np.stack([np.angle(_z(ph, h[0])) for h in hv], axis=1)
        pb = np.stack([np.angle(_z(ph, h[1])) for h in hv], axis=1)
        for i in range(M):
            for j in range(i + 1, M):
                f = fit_washboard_iv(wrap(pa[:, i] - pa[:, j]),
                                     wrap(pb[:, i] - pb[:, j]), tr)
                Ks.append(f["K"]); Ds.append(f["D"])
                dOs.append(abs(f["dOmega"])); Kn.append(f["K_naive"])
    R = np.abs(np.exp(1j * psi).mean(axis=1))
    return dict(K_hat=float(np.nanmean(Ks)), D_hat=float(np.nanmean(Ds)),
                dOmega_hat=float(np.nanmean(dOs)), K_naive=float(np.nanmean(Kn)),
                r_intra=float(np.mean([debias_r(v, n) for v, n in
                                       zip(r.mean(0), [len(ix) for ix in members])])),
                sync_R=float(R.mean()), meta_R=float(R.std(ddof=1)))


def validation_B(n_rep=10, seed=5):
    n_per = (34, 21, 32, 33, 22)
    off = np.cumsum((0,) + n_per)
    members = [np.arange(off[i], off[i + 1]) for i in range(len(n_per))]
    rows = []
    for K_out in (0.05, 0.10, 0.20, 0.35, 0.50, 0.70):
        for rep in range(n_rep):
            X = forward_simulate(K_out, n_per=n_per, seed=seed + 1000 * rep
                                 + int(K_out * 100))
            m = run_pipeline(X, 2.0, members, seed=seed + rep)
            m.update(K_out_true=K_out, rep=rep)
            rows.append(m)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "validation_B.csv"), index=False)
    from scipy.stats import spearmanr
    rho, p = spearmanr(df.K_out_true, df.K_hat)
    rho_n, p_n = spearmanr(df.K_out_true, df.K_naive)
    rho_r, _ = spearmanr(df.K_out_true, df.r_intra)
    rho_m, _ = spearmanr(df.K_out_true, df.meta_R)
    print("\n=== VALIDATION B: full forward model ===")
    print(df.groupby("K_out_true")[["K_hat", "K_naive", "D_hat", "dOmega_hat",
                                    "r_intra", "sync_R", "meta_R"]]
          .mean().round(4).to_string())
    print(f"\nSpearman rho(K_true, K_hat_IV)    = {rho:.3f}  (p={p:.2e})")
    print(f"Spearman rho(K_true, K_hat_naive) = {rho_n:.3f} (p={p_n:.2e})")
    print(f"Spearman rho(K_true, r_intra)     = {rho_r:.3f}")
    print(f"Spearman rho(K_true, meta_R)      = {rho_m:.3f}")
    return df


if __name__ == "__main__":
    validation_A()
    validation_B()
