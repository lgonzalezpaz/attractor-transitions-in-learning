"""
abn_core.py — Observables and closed-form theory for Attractor-Based
Neuroeducation (ABN).

This module contains two things only:

  (1) OBSERVABLES.  Robust, long-time-average statistics of module-level BOLD
      phase dynamics: module coherence r_m, assembly coherence R(t), its
      metastability SD[R], assembly size k(t), inter-module phase locking,
      phase-slip rate, and dwell times.  No attempt is made here to estimate
      latent coupling by local drift regression: the finite-size error of a
      module mean phase (SD = sqrt((1-r^2)/(2 N r^2)), of order 0.4 rad at the
      coherence levels observed in BOLD) attenuates such estimates by close to
      an order of magnitude, as shown in 03_estimator_validation.py.  Latent
      parameters are instead recovered by simulation-based inversion
      (abn_model.py), in which the identical measurement bias is present in
      the simulated and the empirical observables and therefore cancels.

  (2) THEORY.  Closed-form expressions for the washboard barrier, the Kramers
      escape time, the critical noise for global coherence, the anchored
      entrainment time, and the learning-feasibility index Lambda.

Author: see manuscript CRediT statement.
License: MIT (code).
"""
from __future__ import annotations

import numpy as np
from scipy.signal import butter, filtfilt, hilbert

# ----------------------------------------------------------------------------
# Constants fixed a priori (pre-specified, not tuned on the data)
# ----------------------------------------------------------------------------
BAND = (0.04, 0.07)          # Hz; band for BOLD phase dynamics
FILTER_ORDER = 2             # Butterworth, zero-phase
DROP_INITIAL = 5             # volumes discarded at run onset
EDGE_SECONDS = 25.0          # trimmed each end (one cycle at the lower edge)
CORTICAL_MODULES = ("default", "fronto-parietal", "cingulo-opercular",
                    "sensorimotor", "occipital")
PHASE_WINDOW = np.pi / 3.0   # half-width defining assembly membership
R_HIGH = 0.85                # integrated-assembly threshold


# ----------------------------------------------------------------------------
# Signal conditioning
# ----------------------------------------------------------------------------
def bandpass(x, tr, band=BAND, order=FILTER_ORDER):
    nyq = 0.5 / tr
    lo, hi = band[0] / nyq, band[1] / nyq
    if not (0 < lo < hi < 1):
        raise ValueError(f"band {band} incompatible with TR={tr}")
    b, a = butter(order, [lo, hi], btype="bandpass")
    return filtfilt(b, a, x, axis=0)


def analytic_phase(x):
    return np.angle(hilbert(x, axis=0))


def wrap(x):
    return (x + np.pi) % (2 * np.pi) - np.pi


def preprocess(ts, tr, drop_initial=DROP_INITIAL, edge_s=EDGE_SECONDS):
    """Standardise, band-pass, trim filter edges, return instantaneous phases."""
    x = np.asarray(ts, dtype=float)[drop_initial:]
    sd = x.std(0)
    x = (x - x.mean(0)) / np.where(sd > 0, sd, 1.0)
    xf = bandpass(x, tr)
    edge = int(np.ceil(edge_s / tr))
    if 2 * edge < xf.shape[0] - 20:
        xf = xf[edge:-edge]
    return analytic_phase(xf)


# ----------------------------------------------------------------------------
# Order parameters
# ----------------------------------------------------------------------------
def module_order(phases, members):
    """Per-module order parameter; returns (r, psi) of shape (T, M)."""
    z = np.stack([np.exp(1j * phases[:, ix]).mean(axis=1) for ix in members],
                 axis=1)
    return np.abs(z), np.angle(z)


def global_order(psi):
    z = np.exp(1j * psi).mean(axis=1)
    return np.abs(z), np.angle(z)


def assembly_size(psi, window=PHASE_WINDOW):
    _, Psi = global_order(psi)
    return (np.abs(wrap(psi - Psi[:, None])) <= window).sum(axis=1)


def debias_r(r_obs, n):
    """Finite-size debiasing: r^2 = (n r_obs^2 - 1)/(n - 1)."""
    if n < 2:
        return np.nan
    v = (n * r_obs ** 2 - 1.0) / (n - 1.0)
    return float(np.sqrt(v)) if v > 0 else 0.0


def slip_rate(phi, dt):
    """2*pi excursions of the unwrapped phase difference per second."""
    unwrapped = np.cumsum(wrap(np.diff(phi)))
    if unwrapped.size == 0:
        return np.nan
    return float((np.ptp(unwrapped) / (2 * np.pi)) / (len(phi) * dt))


def dwell_stats(series, threshold, dt):
    """Mean dwell time above/below a threshold and the switching rate."""
    hi = series >= threshold
    if hi.all() or (~hi).all():
        return {"dwell_hi_s": np.nan, "dwell_lo_s": np.nan,
                "switch_per_min": 0.0}
    change = np.flatnonzero(np.diff(hi.astype(int)) != 0)
    bounds = np.concatenate([[-1], change, [len(hi) - 1]])
    lens = np.diff(bounds)
    states = hi[bounds[1:]]
    dh = lens[states] * dt
    dl = lens[~states] * dt
    return {"dwell_hi_s": float(dh.mean()) if dh.size else np.nan,
            "dwell_lo_s": float(dl.mean()) if dl.size else np.nan,
            "switch_per_min": float(60.0 * len(change) / (len(hi) * dt))}


# ----------------------------------------------------------------------------
# The observable vector (identical for empirical and simulated data)
# ----------------------------------------------------------------------------
OBS_KEYS = ("sync_R", "meta_R", "r_intra_raw", "plv_bar", "slip_rate_bar",
            "p_k_ge_4", "switch_per_min", "delta_emp")

# A-priori target sub-assembly: the cognitive-control triad whose dynamic
# interaction Supekar et al. (2021) found to predict circumscribed interests
# and insistence on sameness specifically, and not repetitive motor behaviour.
CC_TRIAD = ("cingulo-opercular", "fronto-parietal", "default")

SHORT = {"default": "DMN", "fronto-parietal": "FP", "cingulo-opercular": "CO",
         "sensorimotor": "SM", "occipital": "OC"}


def observables(phases, tr, members, module_names=CORTICAL_MODULES,
                r_threshold=None):
    """Compute the full observable set from instantaneous phases."""
    r, psi = module_order(phases, members)
    R, _ = global_order(psi)
    k = assembly_size(psi)
    M = psi.shape[1]

    plvs, nus, pair_detail = [], [], {}
    for i in range(M):
        for j in range(i + 1, M):
            phi = wrap(psi[:, i] - psi[:, j])
            p = float(np.abs(np.exp(1j * phi).mean()))
            nu = slip_rate(phi, tr)
            plvs.append(p)
            nus.append(nu)
            tag = f"{SHORT[module_names[i]]}_{SHORT[module_names[j]]}"
            pair_detail[f"plv_{tag}"] = p
            pair_detail[f"slip_{tag}"] = nu

    thr = float(np.median(R)) if r_threshold is None else float(r_threshold)
    dw = dwell_stats(R, thr, tr)

    omega = np.array([np.mean(wrap(np.diff(psi[:, j])) / tr) for j in range(M)])

    out = {
        "n_tp_used": int(phases.shape[0]),
        "duration_s": float(phases.shape[0] * tr),
        "sync_R": float(R.mean()),
        "meta_R": float(R.std(ddof=1)),
        "p_R_ge_085": float((R >= R_HIGH).mean()),
        "mean_assembly_k": float(k.mean()),
        "p_k_ge_4": float((k >= 4).mean()),
        "p_k_ge_3": float((k >= 3).mean()),
        "r_intra_raw": float(r.mean()),
        "r_intra_debiased": float(np.mean([debias_r(v, len(ix))
                                           for v, ix in zip(r.mean(0), members)])),
        "plv_bar": float(np.nanmean(plvs)),
        "slip_rate_bar": float(np.nanmean(nus)),
        "omega_mean_hz": float(omega.mean() / (2 * np.pi)),
        "omega_spread_rad_s": float(omega.std(ddof=1)),
        "delta_emp": float(0.5 * np.mean(np.abs(
            omega[:, None] - omega[None, :])[np.triu_indices(M, 1)])),
        "R_threshold_used": thr,
    }
    out.update(dw)
    out.update(pair_detail)
    for v, nm, ix in zip(r.mean(0), module_names, members):
        out[f"r_{nm}"] = float(v)
        out[f"rdb_{nm}"] = debias_r(float(v), len(ix))

    # ---- a-priori cognitive-control triad -------------------------------
    tri = [module_names.index(m) for m in CC_TRIAD]
    psi_t = psi[:, tri]
    R_t, _ = global_order(psi_t)
    k_t = assembly_size(psi_t)
    dw_t = dwell_stats(R_t, float(np.median(R_t)), tr)
    out.update({
        "cc_sync": float(R_t.mean()),
        "cc_meta": float(R_t.std(ddof=1)),
        "cc_p_high": float((R_t >= R_HIGH).mean()),
        "cc_mean_k": float(k_t.mean()),
        "cc_switch_per_min": dw_t["switch_per_min"],
        "cc_dwell_hi_s": dw_t["dwell_hi_s"],
        "cc_plv_bar": float(np.mean([out[f"plv_{SHORT[a]}_{SHORT[b]}"]
                                     if f"plv_{SHORT[a]}_{SHORT[b]}" in out
                                     else out[f"plv_{SHORT[b]}_{SHORT[a]}"]
                                     for a, b in ((CC_TRIAD[0], CC_TRIAD[1]),
                                                  (CC_TRIAD[0], CC_TRIAD[2]),
                                                  (CC_TRIAD[1], CC_TRIAD[2]))])),
    })
    return out


def obs_vector(d):
    return np.array([d[k] for k in OBS_KEYS], dtype=float)


# ============================================================================
# THEORY — closed forms
# ============================================================================
def barrier(K_eff: float, dOmega: float) -> float:
    """Forward escape barrier of the washboard U(phi) = -dOmega*phi - K*cos(phi):

        dU = K [ 2 sqrt(1 - a^2) - |a| (pi - 2 arcsin|a|) ],   a = dOmega / K

    Equals 2K at zero detuning and vanishes as |a| -> 1.  NaN when unlocked.
    """
    K_eff = float(K_eff)
    if not np.isfinite(K_eff) or K_eff <= 0 or not np.isfinite(dOmega):
        return np.nan
    a = abs(float(dOmega) / K_eff)
    if a >= 1.0:
        return np.nan
    return K_eff * (2.0 * np.sqrt(1.0 - a * a) - a * (np.pi - 2.0 * np.arcsin(a)))


def kramers_prefactor(K_eff: float, dOmega: float) -> float:
    """tau_0 = 2 pi / (K sqrt(1 - a^2))  [s]; geometric mean of the curvatures."""
    K_eff = float(K_eff)
    if not np.isfinite(K_eff) or K_eff <= 0:
        return np.nan
    a = abs(float(dOmega) / K_eff)
    if a >= 1.0:
        return np.nan
    return 2.0 * np.pi / (K_eff * np.sqrt(1.0 - a * a))


def escape_time(K_eff: float, dOmega: float, D: float) -> float:
    """Mean first-passage time out of the locked state (Kramers, overdamped)."""
    dU = barrier(K_eff, dOmega)
    t0 = kramers_prefactor(K_eff, dOmega)
    if not np.isfinite(dU) or not np.isfinite(t0) or D <= 0:
        return np.nan
    return t0 * np.exp(dU / D)


def critical_noise(K: float, delta: float) -> float:
    """Noise intensity at which module-level global coherence collapses.

    For the noisy Kuramoto mean field with Lorentzian detuning half-width
    delta, the incoherent state loses stability at K_c = 2 (D + delta); hence
    coherence requires D < D_c = K/2 - delta, i.e. sigma_c = sqrt(2 D_c).
    """
    return 0.5 * float(K) - float(delta)


def escape_noise(K_eff: float, dOmega: float, T_session: float) -> float:
    """Noise intensity needed to escape the locked state within T_session."""
    dU = barrier(K_eff, dOmega)
    t0 = kramers_prefactor(K_eff, dOmega)
    if not np.isfinite(dU) or not np.isfinite(t0) or T_session <= t0:
        return np.nan
    return dU / np.log(T_session / t0)


def Lambda(K: float, delta: float, K_eff: float, dOmega: float,
           T_session: float) -> float:
    """Learning-feasibility index Lambda = D_c / D_esc.

    Lambda > 1  : a noise level exists that both escapes the attractor within
                  the session and preserves global coherence.
    Lambda <= 1 : no such noise level exists — perturbation-driven learning is
                  dynamically infeasible, however the perturbation is tuned.
    """
    D_c = critical_noise(K, delta)
    D_esc = escape_noise(K_eff, dOmega, T_session)
    if not np.isfinite(D_esc) or D_esc <= 0:
        return np.nan
    return D_c / D_esc


def entrainment_time(K_anchor: float, dOmega: float, phi0: float = np.pi / 2,
                     tol: float = 0.05) -> float:
    """Deterministic time for an anchored oscillator to reach its locked phase.

    For dphi/dt = dOmega - K sin(phi) with K > |dOmega| the solution is
    obtained in closed form; the time to come within tol of the fixed point
    phi* = arcsin(dOmega/K) is

        T = (2 / sqrt(K^2 - dOmega^2)) * | artanh(u(phi0)) - artanh(u(phi*+tol)) |

    with u(phi) = (K - dOmega tan(phi/2)) / sqrt(K^2 - dOmega^2) ... evaluated
    numerically below for robustness.  Scales as (K^2 - dOmega^2)^(-1/2):
    algebraic in the control parameter, never exponential.
    """
    K_anchor, dOmega = float(K_anchor), float(dOmega)
    if K_anchor <= abs(dOmega):
        return np.inf
    s = np.sqrt(K_anchor ** 2 - dOmega ** 2)
    phi_star = np.arcsin(dOmega / K_anchor)
    target = phi_star + np.sign(phi0 - phi_star) * tol
    if abs(phi0 - phi_star) <= tol:
        return 0.0
    grid = np.linspace(phi0, target, 4000)
    v = dOmega - K_anchor * np.sin(grid)
    if np.any(np.abs(v) < 1e-12):
        return np.inf
    return float(abs(np.trapezoid(1.0 / v, grid)))


def anchoring_gain(K_eff: float, dOmega_target: float, D: float,
                   K_anchor: float, dOmega_anchor: float) -> float:
    """Ratio of noise-driven escape time to anchored entrainment time."""
    t_esc = escape_time(K_eff, dOmega_target, D)
    t_lock = entrainment_time(K_anchor, dOmega_anchor)
    if not np.isfinite(t_esc) or not np.isfinite(t_lock) or t_lock <= 0:
        return np.nan
    return t_esc / t_lock


def consolidated_coupling(t: float, kappa_inf: float, tau_c: float) -> float:
    """Structural consolidation of an attractor: K(t) = K_inf (1 - exp(-t/tau_c))."""
    return float(kappa_inf) * (1.0 - np.exp(-float(t) / float(tau_c)))


# ============================================================================
# Critical coupling for a general unimodal frequency distribution
# ============================================================================
def _coherence_integral(D: float, s: float, n: int = 4001) -> float:
    """I(D) = int g(w) D/(D^2 + w^2) dw for a zero-mean Gaussian g of SD s."""
    if D <= 0:
        return np.inf
    lim = max(8.0 * s, 8.0 * D)
    w = np.linspace(-lim, lim, n)
    g = np.exp(-0.5 * (w / s) ** 2) / (s * np.sqrt(2 * np.pi))
    return float(np.trapezoid(g * D / (D ** 2 + w ** 2), w))


def critical_coupling_gaussian(D: float, s: float) -> float:
    """K_c(D) = 2 / I(D) — the coupling at which incoherence loses stability.

    Reduces to 2/(pi g(0)) = 2 s sqrt(2/pi) as D -> 0 and to 2D as D -> inf.
    Derived from the linear-stability condition of the noisy Kuramoto mean
    field (Strogatz & Mirollo 1991, eq. 3.15), specialised to a Gaussian
    frequency density rather than the Lorentzian for which the familiar
    K_c = 2(D + delta) holds.
    """
    I = _coherence_integral(D, s)
    return 2.0 / I if I > 0 else np.inf


def critical_noise_gaussian(K: float, s: float, hi: float = 50.0,
                            tol: float = 1e-9) -> float:
    """Largest noise intensity D compatible with module-level coherence.

    Solves K_c(D) = K for D.  Returns a negative sentinel when K lies below
    the zero-noise threshold 2 s sqrt(2/pi), i.e. when the population is
    incoherent even without noise.
    """
    K, s = float(K), float(s)
    if s <= 0:
        return np.inf
    K0 = 2.0 * s * np.sqrt(2.0 / np.pi)      # K_c at D -> 0
    if K <= K0:
        return K - K0                         # negative: subcritical already
    lo = 1e-12
    if critical_coupling_gaussian(hi, s) < K:
        return hi
    while hi - lo > tol * max(1.0, hi):
        mid = 0.5 * (lo + hi)
        if critical_coupling_gaussian(mid, s) < K:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def Lambda_gaussian(K: float, s: float, Rbar: float, dOmega: float,
                    T_session: float) -> float:
    """Feasibility index with the Gaussian critical noise and K_eff = K*Rbar."""
    D_c = critical_noise_gaussian(K, s)
    D_esc = escape_noise(K * Rbar, dOmega, T_session)
    if not np.isfinite(D_esc) or D_esc <= 0:
        return np.nan
    return D_c / D_esc


def required_coupling_gain(K: float, s: float, Rbar: float, dOmega: float,
                           T_session: float, g_max: float = 1e4) -> float:
    """Multiplier G* of the inter-module coupling at which Lambda = 1.

    Instruction is modelled as a transient increase of the assembly coupling
    K -> G*K at fixed frequency dispersion.  G* is the smallest gain for which
    a noise level exists that both escapes the prior attractor within the
    session and sustains assembly coherence.  G* <= 1 means the resting
    configuration is already feasible.
    """
    def lam(G):
        return Lambda_gaussian(G * K, s, Rbar, dOmega, T_session)

    if not np.isfinite(K) or K <= 0:
        return np.nan
    l1 = lam(1.0)
    if np.isfinite(l1) and l1 >= 1.0:
        return 1.0
    lo, hi = 1.0, 2.0
    while hi < g_max:
        v = lam(hi)
        if np.isfinite(v) and v >= 1.0:
            break
        lo, hi = hi, hi * 2.0
    else:
        return np.nan
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        v = lam(mid)
        if np.isfinite(v) and v >= 1.0:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)


def barrier_backward(K_eff: float, dOmega: float) -> float:
    """Backward escape barrier: dU_- = K [2 sqrt(1-a^2) + |a|(pi - 2 arcsin|a|)]."""
    K_eff = float(K_eff)
    if not np.isfinite(K_eff) or K_eff <= 0 or not np.isfinite(dOmega):
        return np.nan
    a = abs(float(dOmega) / K_eff)
    if a >= 1.0:
        return np.nan
    return K_eff * (2.0 * np.sqrt(1.0 - a * a) + a * (np.pi - 2.0 * np.arcsin(a)))


def mfpt_to_saddle(K_eff: float, dOmega: float, D: float) -> float:
    """Mean first-passage time out of the locked state, both channels.

    The quantity simulated in 06_theory.py is the first passage to either
    barrier top, for which the asymptotic prefactor is pi / sqrt(|U''|_min
    |U''|_max) rather than the 2 pi of the well-to-well rate, and the two
    escape directions add their rates:

        1/tau = 1/tau_+ + 1/tau_- ,
        tau_+- = [pi / (K sqrt(1-a^2))] exp(dU_+- / D).
    """
    if D <= 0:
        return np.nan
    dUp, dUm = barrier(K_eff, dOmega), barrier_backward(K_eff, dOmega)
    if not np.isfinite(dUp):
        return np.nan
    a = abs(float(dOmega) / float(K_eff))
    pref = np.pi / (float(K_eff) * np.sqrt(1.0 - a * a))
    rate = 1.0 / (pref * np.exp(dUp / D)) + 1.0 / (pref * np.exp(dUm / D))
    return 1.0 / rate if rate > 0 else np.inf
