"""
01_build_cohort.py — Pre-specified cohort construction from ABIDE I Preprocessed.

Inclusion criteria (fixed before any dynamical metric was computed):
  1. A preprocessed functional run exists (FILE_ID != 'no_filename').
  2. Diagnostic group is ASD (DX_GROUP == 1) or typically developing (== 2).
  3. Age at scan 6.0-18.0 years (school age; the population to which the
     educational inference applies).
  4. Functional QC rating by rater 2 is not 'fail'.
  5. Mean framewise displacement < 0.20 mm.
  6. Site repetition time is known and documented.

Output: results/cohort.csv
"""
from __future__ import annotations
import os
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
RES = os.path.join(ROOT, "results")
os.makedirs(RES, exist_ok=True)

# Repetition time per ABIDE I site (seconds). Values cross-checked against two
# independent published tabulations of the ABIDE acquisition parameters.
TR_BY_SITE = {
    "CALTECH": 2.000, "CMU": 2.000, "KKI": 2.500,
    "LEUVEN_1": 1.667, "LEUVEN_2": 1.667, "MAX_MUN": 3.000,
    "NYU": 2.000, "OHSU": 2.500, "OLIN": 1.500, "PITT": 1.500,
    "SBL": 2.200, "SDSU": 2.000, "STANFORD": 2.000, "TRINITY": 2.000,
    "UCLA_1": 3.000, "UCLA_2": 3.000, "UM_1": 2.000, "UM_2": 2.000,
    "USM": 2.000, "YALE": 2.000,
}

AGE_MIN, AGE_MAX = 6.0, 18.0
FD_MAX = 0.20
MISSING = (-9999, -999, 9999)


def main():
    ph = pd.read_csv(os.path.join(DATA, "abide_pheno.csv"),
                     encoding="latin-1", low_memory=False)
    n0 = len(ph)
    log = [("released ABIDE I records", n0)]

    ph = ph[ph.FILE_ID != "no_filename"].copy()
    log.append(("preprocessed run available", len(ph)))

    ph = ph[ph.DX_GROUP.isin([1, 2])]
    log.append(("ASD or TD", len(ph)))

    ph = ph[(ph.AGE_AT_SCAN >= AGE_MIN) & (ph.AGE_AT_SCAN <= AGE_MAX)]
    log.append((f"age {AGE_MIN}-{AGE_MAX} y", len(ph)))

    ph = ph[ph.qc_func_rater_2.astype(str).str.lower() != "fail"]
    log.append(("functional QC not 'fail'", len(ph)))

    ph = ph[ph.func_mean_fd.notna() & (ph.func_mean_fd < FD_MAX)]
    log.append((f"mean FD < {FD_MAX} mm", len(ph)))

    ph = ph[ph.SITE_ID.isin(TR_BY_SITE)]
    ph["TR"] = ph.SITE_ID.map(TR_BY_SITE)
    log.append(("documented TR", len(ph)))

    keep = ["FILE_ID", "SITE_ID", "TR", "DX_GROUP", "AGE_AT_SCAN", "SEX",
            "FIQ", "HANDEDNESS_CATEGORY", "EYE_STATUS_AT_SCAN", "func_mean_fd",
            "ADI_R_SOCIAL_TOTAL_A", "ADI_R_VERBAL_TOTAL_BV", "ADI_RRB_TOTAL_C",
            "ADOS_TOTAL", "ADOS_STEREO_BEHAV", "ADOS_GOTHAM_RRB",
            "ADOS_GOTHAM_SEVERITY", "SRS_RAW_TOTAL", "SRS_MANNERISMS",
            "SRS_COGNITION"]
    coh = ph[keep].copy()
    for c in keep:
        if coh[c].dtype.kind in "if":
            coh[c] = coh[c].replace(list(MISSING), np.nan)

    coh["group"] = np.where(coh.DX_GROUP == 1, "ASD", "TD")
    coh.to_csv(os.path.join(RES, "cohort.csv"), index=False)

    with open(os.path.join(RES, "cohort_flow.txt"), "w") as fh:
        for k, v in log:
            fh.write(f"{k}\t{v}\n")
        fh.write("\nby group\n")
        fh.write(coh.group.value_counts().to_string())
        fh.write("\n\nby site x group\n")
        fh.write(pd.crosstab(coh.SITE_ID, coh.group).to_string())

    print("\n".join(f"{k}: {v}" for k, v in log))
    print(coh.group.value_counts().to_dict())
    print(pd.crosstab(coh.SITE_ID, coh.group).to_string())
    print("\nADI_RRB_TOTAL_C in ASD:", coh.loc[coh.group == "ASD", "ADI_RRB_TOTAL_C"].notna().sum())
    print("ADOS_GOTHAM_RRB in ASD:", coh.loc[coh.group == "ASD", "ADOS_GOTHAM_RRB"].notna().sum())
    print("SRS total:", coh.SRS_RAW_TOTAL.notna().sum())


if __name__ == "__main__":
    main()
