"""
09_figures.py — Manuscript figures.

All figures are written as vector PDF and as 600-dpi PNG, use a single
colour-blind-safe palette that remains legible in greyscale, and carry no
colour-only encoding.

Figure 1  The model and the two obstructions (schematic + washboard potential
          + coherence collapse).
Figure 2  Verification of the closed forms: Kramers escape, coherence collapse
          with finite-size smearing, adiabatic sweep scaling.
Figure 3  The feasibility boundary and the anchoring gain.
Figure 4  Estimator validation and parameter recovery.
Figure 5  Empirical observables and inverted parameters in ABIDE.
Figure 6  Surrogate control.
Figure 7  Instructional protocols.
"""
from __future__ import annotations
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from abn_core import (barrier, critical_coupling_gaussian,  # noqa: E402
                      critical_noise_gaussian, entrainment_time, escape_noise,
                      escape_time, kramers_prefactor, mfpt_to_saddle)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)

# Colour-blind-safe, greyscale-separable
C = {"asd": "#B2182B", "td": "#2166AC", "k1": "#1A1A1A", "k2": "#636363",
     "k3": "#969696", "acc": "#D95F02", "acc2": "#7570B3", "acc3": "#1B9E77"}
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8,
    "axes.titlesize": 8.5, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "legend.fontsize": 7, "axes.linewidth": 0.7, "lines.linewidth": 1.2,
    "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 150, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
S_RAD = 2 * np.pi * 0.006
D_OM = 2 * S_RAD / np.sqrt(np.pi)


def save(fig, name):
    fig.savefig(os.path.join(FIG, f"{name}.pdf"))
    fig.savefig(os.path.join(FIG, f"{name}.png"), dpi=600)
    plt.close(fig)
    print(f"  wrote figures/{name}.pdf/.png")


def panel(ax, letter):
    ax.text(-0.26, 1.10, letter, transform=ax.transAxes, fontsize=10,
            fontweight="bold", va="top", ha="left")


# ---------------------------------------------------------------------------
def fig1():
    fig = plt.figure(figsize=(7.1, 4.4))
    gs = fig.add_gridspec(2, 3, hspace=0.52, wspace=0.38)

    # (a) washboard potential at three detunings
    ax = fig.add_subplot(gs[0, 0])
    phi = np.linspace(-1.2 * np.pi, 2.2 * np.pi, 800)
    K = 1.0
    for a, c, ls in ((0.0, C["k1"], "-"), (0.4, C["k2"], "--"),
                     (0.85, C["k3"], ":")):
        U = -a * K * phi - K * np.cos(phi)
        ax.plot(phi / np.pi, U - U.min(), color=c, ls=ls,
                label=fr"$a={a}$")
    ax.set_xlabel(r"phase difference $\varphi/\pi$")
    ax.set_ylabel(r"$U(\varphi)/K$")
    ax.set_title("Locked state and its barrier")
    ax.legend(frameon=False, handlelength=1.6)
    panel(ax, "a")

    # (b) barrier versus detuning
    ax = fig.add_subplot(gs[0, 1])
    aa = np.linspace(0, 0.999, 400)
    ax.plot(aa, [barrier(1.0, x) for x in aa], color=C["k1"])
    ax.axhline(2, color=C["k3"], lw=0.6, ls=":")
    ax.text(0.04, 2.04, r"$\Delta U = 2K$", fontsize=6.5, color=C["k3"])
    ax.set_xlabel(r"detuning ratio $a=\Delta\omega/K_{\mathrm{eff}}$")
    ax.set_ylabel(r"$\Delta U / K_{\mathrm{eff}}$")
    ax.set_title("Barrier vanishes at locking edge")
    panel(ax, "b")

    # (c) escape time versus noise
    ax = fig.add_subplot(gs[0, 2])
    Dg = np.geomspace(0.01, 1.0, 300)
    for Keff, c, ls in ((0.05, C["k3"], ":"), (0.12, C["k2"], "--"),
                        (0.30, C["k1"], "-")):
        ax.plot(Dg, [escape_time(Keff, D_OM, D) for D in Dg], color=c, ls=ls,
                label=fr"$K_{{\mathrm{{eff}}}}={Keff}$")
    ax.axhline(1800, color=C["acc"], lw=0.8)
    ax.text(0.011, 2600, "30-min session", fontsize=6.5, color=C["acc"])
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_ylim(1, 1e14)
    ax.set_xlabel(r"noise intensity $D$")
    ax.set_ylabel(r"$\tau_{\mathrm{esc}}$  (s)")
    ax.set_title("Escape needs large noise")
    ax.legend(frameon=False, handlelength=1.6, loc="upper right")
    panel(ax, "c")

    # (d) critical coupling curve
    ax = fig.add_subplot(gs[1, 0])
    Dg = np.geomspace(1e-4, 1.0, 200)
    Kc = [critical_coupling_gaussian(D, S_RAD) for D in Dg]
    ax.plot(Dg, Kc, color=C["k1"])
    ax.fill_between(Dg, Kc, 10, color=C["acc3"], alpha=0.16, lw=0)
    ax.fill_between(Dg, 1e-3, Kc, color=C["asd"], alpha=0.12, lw=0)
    ax.text(2e-4, 0.5, "coherent", fontsize=6.5, color=C["acc3"])
    ax.text(0.03, 0.006, "incoherent", fontsize=6.5, color=C["asd"])
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_ylim(3e-3, 5)
    ax.set_xlabel(r"noise intensity $D$")
    ax.set_ylabel(r"$K_c(D)$")
    ax.set_title("Coherence needs small noise")
    panel(ax, "d")

    # (e) the two requirements collide
    ax = fig.add_subplot(gs[1, 1])
    Kg = np.geomspace(0.03, 1.5, 300)
    Dc = np.array([critical_noise_gaussian(k, S_RAD) for k in Kg])
    De = np.array([escape_noise(k * 0.6, D_OM, 1800.0) for k in Kg])
    ax.plot(Kg, np.where(Dc > 0, Dc, np.nan), color=C["acc3"],
            label=r"$D_c$  (coherence ceiling)")
    ax.plot(Kg, De, color=C["asd"], ls="--",
            label=r"$D_{\mathrm{esc}}$  (escape floor)")
    ok = (Dc > De) & (Dc > 0)
    ax.fill_between(Kg, De, np.where(Dc > 0, Dc, np.nan), where=ok,
                    color=C["acc3"], alpha=0.18, lw=0)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"assembly coupling $K$")
    ax.set_ylabel(r"noise intensity $D$")
    ax.set_title("Feasible window (shaded)")
    ax.legend(frameon=False, handlelength=1.8, loc="lower right")
    panel(ax, "e")

    # (f) Lambda versus K
    ax = fig.add_subplot(gs[1, 2])
    for Rb, c, ls in ((0.5, C["k3"], ":"), (0.6, C["k2"], "--"),
                      (0.8, C["k1"], "-")):
        lam = []
        for k in Kg:
            dc = critical_noise_gaussian(k, S_RAD)
            de = escape_noise(k * Rb, D_OM, 1800.0)
            lam.append(dc / de if (np.isfinite(de) and de > 0) else np.nan)
        ax.plot(Kg, lam, color=c, ls=ls, label=fr"$\bar R={Rb}$")
    ax.axhline(1, color=C["acc"], lw=0.8)
    ax.set_xscale("log")
    ax.set_ylim(-4, 8)
    ax.set_xlabel(r"assembly coupling $K$")
    ax.set_ylabel(r"$\Lambda$")
    ax.set_title(r"Feasibility index")
    ax.legend(frameon=False, handlelength=1.6, loc="lower right")
    panel(ax, "f")
    save(fig, "figure1_model")


# ---------------------------------------------------------------------------
def fig2():
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.3))
    plt.subplots_adjust(wspace=0.42)

    a = pd.read_csv(os.path.join(RES, "theory_A_kramers.csv"))
    ax = axes[0]
    for (K, aa), g in a.groupby(["K", "a"]):
        ax.plot(g.pred_saddle, g.tau_sim, "o", ms=3.4, mfc="none", mew=0.9,
                color=C["k1"] if K == 0.05 else C["acc2"])
    lim = [a.pred_saddle.min() * 0.6, a.pred_saddle.max() * 1.8]
    ax.plot(lim, lim, color=C["k3"], lw=0.7, ls=":")
    ax.plot(lim, [1.281 * x for x in lim], color=C["asd"], lw=0.9)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"predicted $\tau$  (s)")
    ax.set_ylabel(r"simulated $\tau$  (s)")
    ax.set_title("Kramers escape")
    ax.legend([Line2D([], [], color=C["k1"], marker="o", ls="none", mfc="none"),
               Line2D([], [], color=C["acc2"], marker="o", ls="none", mfc="none"),
               Line2D([], [], color=C["asd"]),
               Line2D([], [], color=C["k3"], ls=":")],
              [r"$K_{\mathrm{eff}}=0.05$", r"$K_{\mathrm{eff}}=0.12$",
               r"$\times 1.28$", "identity"],
              frameon=False, handlelength=1.4, loc="upper left")
    panel(ax, "a")

    b = pd.read_csv(os.path.join(RES, "theory_B_collapse.csv"))
    ax = axes[1]
    for M, c, mk in ((5, C["asd"], "s"), (60, C["k1"], "o")):
        g = b[b.M == M].groupby("K_over_Kc").R.mean()
        ax.plot(g.index, g.values, marker=mk, ms=3.4, color=c, mfc="none",
                mew=0.9, label=f"$M={M}$ modules")
    ax.axvline(1.0, color=C["acc"], lw=0.8)
    ax.set_xscale("log")
    ax.set_xlabel(r"$K / K_c(D)$")
    ax.set_ylabel(r"$\langle R\rangle$")
    ax.set_title("Collapse and finite-size floor")
    ax.legend(frameon=False, handlelength=1.4, loc="lower right")
    panel(ax, "b")

    e = pd.read_csv(os.path.join(RES, "theory_E_sweep.csv"))
    ax = axes[2]
    ax.plot(e.rate, e.delay, "o", ms=3.4, color=C["k1"], mfc="none", mew=0.9,
            label="simulated")
    ax.plot(e.rate, e.pred, color=C["asd"], lw=0.9, label=r"$\propto r^{2/3}$")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"sweep rate $r$  (rad s$^{-2}$)")
    ax.set_ylabel(r"unlocking delay  (rad s$^{-1}$)")
    ax.set_title("Slow passage")
    ax.legend(frameon=False, handlelength=1.4, loc="upper left")
    panel(ax, "c")
    save(fig, "figure2_verification")


# ---------------------------------------------------------------------------
def fig3():
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.4))
    plt.subplots_adjust(wspace=0.46)

    # (a) Lambda map
    ax = axes[0]
    Kg = np.geomspace(0.03, 1.5, 90)
    Rg = np.linspace(0.35, 0.95, 70)
    Z = np.empty((len(Rg), len(Kg)))
    for i, Rb in enumerate(Rg):
        for j, k in enumerate(Kg):
            dc = critical_noise_gaussian(k, S_RAD)
            de = escape_noise(k * Rb, D_OM, 1800.0)
            Z[i, j] = dc / de if (np.isfinite(de) and de > 0) else np.nan
    m = ax.pcolormesh(Kg, Rg, np.clip(Z, -2, 6), cmap="RdYlBu", shading="auto",
                      vmin=-2, vmax=6, rasterized=True)
    cs = ax.contour(Kg, Rg, Z, levels=[1.0], colors=[C["k1"]], linewidths=1.1)
    ax.clabel(cs, fmt={1.0: r"$\Lambda=1$"}, fontsize=6.5)
    ax.set_xscale("log")
    ax.set_xlabel(r"assembly coupling $K$")
    ax.set_ylabel(r"assembly coherence $\bar R$")
    ax.set_title("Feasibility landscape")
    cb = fig.colorbar(m, ax=ax, pad=0.02, fraction=0.05)
    cb.set_label(r"$\Lambda$", fontsize=7)
    cb.ax.tick_params(labelsize=6)
    panel(ax, "a")

    # (b) escape versus entrainment time
    ax = axes[1]
    Kg = np.geomspace(0.03, 1.0, 200)
    for D, c, ls in ((0.05, C["k3"], ":"), (0.15, C["k2"], "--"),
                     (0.45, C["k1"], "-")):
        ax.plot(Kg, [escape_time(k, D_OM, D) for k in Kg], color=c, ls=ls,
                label=fr"escape, $D={D}$")
    for mult, c in ((1.5, C["acc"]), (8.0, C["acc3"])):
        ax.axhline(entrainment_time(mult * abs(D_OM), D_OM), color=c, lw=0.9)
        ax.text(0.032, entrainment_time(mult * abs(D_OM), D_OM) * 1.25,
                fr"anchored, $K_a/|\Delta\omega|={mult}$", fontsize=6.2,
                color=c)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"$K_{\mathrm{eff}}$ of the prior attractor")
    ax.set_ylabel("time to reconfigure  (s)")
    ax.set_title("Exponential versus algebraic cost")
    ax.legend(frameon=False, handlelength=1.6, loc="upper left")
    panel(ax, "b")

    # (c) consolidation
    ax = axes[2]
    f = pd.read_csv(os.path.join(RES, "theory_F_consolidation.csv"))
    for tc, c, ls in ((1.0, C["k3"], ":"), (7.0, C["k2"], "--"),
                      (30.0, C["k1"], "-")):
        g = f[f.tau_c_days == tc]
        ax.plot(g.t_days, g.tau_esc_s, color=c, ls=ls,
                label=fr"$\tau_c={tc:g}$ d")
    ax.axhline(1800, color=C["acc"], lw=0.8)
    ax.text(0.06, 2300, "30-min session", fontsize=6.2, color=C["acc"])
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("time since first encoding  (days)")
    ax.set_ylabel(r"$\tau_{\mathrm{esc}}$ of the error  (s)")
    ax.set_title("Cost of correcting a consolidated error")
    ax.legend(frameon=False, handlelength=1.6, loc="lower right")
    panel(ax, "c")
    save(fig, "figure3_feasibility")


# ---------------------------------------------------------------------------
def fig4():
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.3))
    plt.subplots_adjust(wspace=0.42)
    from scipy.stats import spearmanr

    a = pd.read_csv(os.path.join(RES, "validation_A_summary.csv"))
    ax = axes[0]
    x = np.arange(len(a))
    ax.bar(x - 0.2, a.D_bias_naive_pct, 0.38, color=C["asd"], label="naive")
    ax.bar(x + 0.2, a.D_bias_iv_pct, 0.38, color=C["k1"], label="split-half")
    ax.set_yscale("symlog", linthresh=10)
    ax.axhline(0, color=C["k3"], lw=0.6)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{k:g}" for k in a.K_true], rotation=0)
    ax.set_xlabel(r"true $K$ (grouped conditions)")
    ax.set_ylabel(r"bias in $D$  (%)")
    ax.set_title("Finite-size bias in local estimators")
    ax.legend(frameon=False, handlelength=1.3, loc="upper right")
    panel(ax, "a")

    r = pd.read_csv(os.path.join(RES, "recovery.csv"))
    ax = axes[1]
    g = r.groupby("K_out").K_out_hat.agg(["median",
                                          lambda v: v.quantile(0.25),
                                          lambda v: v.quantile(0.75)])
    g.columns = ["med", "q1", "q3"]
    ax.plot([g.index.min(), g.index.max()], [g.index.min(), g.index.max()],
            color=C["k3"], ls=":", lw=0.7)
    ax.errorbar(g.index, g.med, yerr=[g.med - g.q1, g.q3 - g.med],
                fmt="o", ms=3.4, color=C["k1"], mfc="none", mew=0.9,
                elinewidth=0.8, capsize=1.6)
    rho, _ = spearmanr(r.K_out, r.K_out_hat)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel(r"true $K$")
    ax.set_ylabel(r"recovered $\hat K$")
    ax.set_title(fr"Coupling recovery ($\rho={rho:.2f}$)")
    panel(ax, "b")

    ax = axes[2]
    g = r.groupby("sigma").sigma_hat.agg(["median",
                                          lambda v: v.quantile(0.25),
                                          lambda v: v.quantile(0.75)])
    g.columns = ["med", "q1", "q3"]
    ax.plot([g.index.min(), g.index.max()], [g.index.min(), g.index.max()],
            color=C["k3"], ls=":", lw=0.7)
    ax.errorbar(g.index, g.med, yerr=[g.med - g.q1, g.q3 - g.med],
                fmt="s", ms=3.4, color=C["acc2"], mfc="none", mew=0.9,
                elinewidth=0.8, capsize=1.6)
    rho, _ = spearmanr(r.sigma, r.sigma_hat)
    ax.set_xlabel(r"true $\sigma$")
    ax.set_ylabel(r"recovered $\hat\sigma$")
    ax.set_title(fr"Noise recovery ($\rho={rho:.2f}$)")
    panel(ax, "c")
    save(fig, "figure4_validation")


# ---------------------------------------------------------------------------
def _violin(ax, d, col, ylab, title):
    parts = []
    for i, (grp, c) in enumerate((("TD", C["td"]), ("ASD", C["asd"]))):
        v = d.loc[d.group == grp, col].dropna().values
        if len(v) < 5:
            continue
        p = ax.violinplot([v], positions=[i], widths=0.74,
                          showextrema=False, showmedians=False)
        for b in p["bodies"]:
            b.set_facecolor(c); b.set_alpha(0.32); b.set_edgecolor(c)
            b.set_linewidth(0.7)
        q1, med, q3 = np.percentile(v, [25, 50, 75])
        ax.plot([i, i], [q1, q3], color=c, lw=1.6, solid_capstyle="round")
        ax.plot(i, med, "o", ms=3.6, color="white", mec=c, mew=1.1, zorder=5)
        parts.append(grp)
    ax.set_xticks(range(len(parts)))
    ax.set_xticklabels(parts)
    ax.set_ylabel(ylab)
    ax.set_title(title)


def fig5():
    d = pd.read_csv(os.path.join(RES, "dynamics_qc.csv"))
    lat = os.path.join(RES, "latent_parameters.csv")
    if os.path.exists(lat):
        d = d.merge(pd.read_csv(lat), on="FILE_ID", how="left")
    st = pd.read_csv(os.path.join(RES, "statistics.csv"))

    pretty = {"sync_R": r"$\langle R\rangle$", "meta_R": r"SD$[R]$",
              "r_intra_raw": r"$r_{\mathrm{intra}}$", "plv_bar": "PLV",
              "switch_per_min": "switching", "cc_sync": r"$\langle R\rangle$ triad",
              "cc_meta": r"SD$[R]$ triad", "cc_plv_bar": "PLV triad",
              "cc_switch_per_min": "switching triad", "K_out_hat": r"$\hat K$",
              "sigma_hat": r"$\hat\sigma$", "K_in_hat": r"$\hat K_{\mathrm{in}}$",
              "dU_hat": r"$\Delta \hat U$", "D_hat": r"$\hat D$",
              "Lambda_hat": r"$\hat\Lambda$",
              "tau_esc_hat_log10": r"$\log_{10}\hat\tau_{\mathrm{esc}}$"}
    fig = plt.figure(figsize=(7.1, 4.5))
    gs = fig.add_gridspec(2, 4, hspace=0.46, wspace=0.58,
                          height_ratios=[1.0, 1.25])

    specs = [("cc_meta", "SD$[R]$, control triad", "Triad metastability"),
             ("cc_switch_per_min", "crossings min$^{-1}$", "Triad switching"),
             ("K_out_hat", r"$\hat K$", "Assembly coupling"),
             ("sigma_hat", r"$\hat\sigma$", "Phase noise")]
    for j, (col, yl, ti) in enumerate(specs):
        ax = fig.add_subplot(gs[0, j])
        if col in d.columns:
            _violin(ax, d, col, yl, ti)
        panel(ax, "abcd"[j])

    # effect-size forest plot
    ax = fig.add_subplot(gs[1, :2])
    sub = st[(st.analysis == "categorical")].dropna(subset=["beta_std"])
    sub = sub.iloc[::-1]
    y = np.arange(len(sub))
    ax.errorbar(sub.beta_std, y,
                xerr=[sub.beta_std - sub.ci_lo, sub.ci_hi - sub.beta_std],
                fmt="o", ms=3.4, color=C["k1"], mfc="white", mew=0.9,
                elinewidth=0.8, capsize=1.8)
    ax.axvline(0, color=C["k3"], lw=0.7, ls=":")
    ax.set_yticks(y)
    ax.set_yticklabels([pretty.get(o, o) for o in sub.outcome], fontsize=6.4)
    ax.set_xlabel("standardised group difference (ASD $-$ TD), 95% CI")
    ax.set_title("Adjusted categorical contrasts")
    panel(ax, "e")

    # Lambda distribution
    ax = fig.add_subplot(gs[1, 2])
    if "Lambda_hat" in d.columns:
        for grp, c in (("TD", C["td"]), ("ASD", C["asd"])):
            v = d.loc[d.group == grp, "Lambda_hat"].dropna()
            ax.hist(v, bins=np.linspace(-6, 10, 33), histtype="step",
                    color=c, lw=1.1, density=True, label=grp)
        ax.axvline(1, color=C["acc"], lw=0.9)
        ax.set_xlabel(r"$\hat\Lambda$")
        ax.set_ylabel("density")
        ax.set_title("Feasibility at rest")
        ax.legend(frameon=False, handlelength=1.3)
    panel(ax, "f")

    # required coupling gain
    ax = fig.add_subplot(gs[1, 3])
    if "gain_star" in d.columns:
        dd = d.copy()
        dd["gain_star"] = np.log2(dd.gain_star.clip(lower=1e-3))
        _violin(ax, dd, "gain_star", r"$\log_2 G^{*}$", "Required gain")
        ax.axhline(0, color=C["acc"], lw=0.8)
        ax.set_ylim(-0.4, 6)
    panel(ax, "g")
    save(fig, "figure5_empirical")


# ---------------------------------------------------------------------------
def fig6():
    p = os.path.join(RES, "surrogate_tests.csv")
    if not os.path.exists(p):
        print("  (skipping figure 6: surrogate results not present)")
        return
    t = pd.read_csv(p)
    s = pd.read_csv(os.path.join(RES, "surrogates.csv"))
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.3))
    plt.subplots_adjust(wspace=0.46)

    ax = axes[0]
    tt = t.iloc[::-1]
    y = np.arange(len(tt))
    ax.barh(y, tt.cohen_dz, color=C["k1"], height=0.62)
    ax.axvline(0, color=C["k3"], lw=0.7)
    ax.set_yticks(y); ax.set_yticklabels(tt.observable, fontsize=6.2)
    ax.set_xlabel(r"real vs own surrogate, $d_z$")
    ax.set_title("Excess over stationary linear")
    panel(ax, "a")

    ax = axes[1]
    ax.plot(s.surr_meta_R, s.real_meta_R, ".", ms=2.2, color=C["k2"], alpha=0.6)
    lo = min(s.surr_meta_R.min(), s.real_meta_R.min())
    hi = max(s.surr_meta_R.max(), s.real_meta_R.max())
    ax.plot([lo, hi], [lo, hi], color=C["k1"], lw=0.8, ls=":")
    ax.set_xlabel("surrogate SD$[R]$")
    ax.set_ylabel("real SD$[R]$")
    ax.set_title("Metastability")
    panel(ax, "b")

    ax = axes[2]
    ax.plot(s.surr_switch_per_min, s.real_switch_per_min, ".", ms=2.2,
            color=C["acc2"], alpha=0.6)
    lo = min(s.surr_switch_per_min.min(), s.real_switch_per_min.min())
    hi = max(s.surr_switch_per_min.max(), s.real_switch_per_min.max())
    ax.plot([lo, hi], [lo, hi], color=C["k1"], lw=0.8, ls=":")
    ax.set_xlabel("surrogate switching")
    ax.set_ylabel("real switching")
    ax.set_title("Switching rate")
    panel(ax, "c")
    save(fig, "figure6_surrogates")


# ---------------------------------------------------------------------------
def fig7():
    p = os.path.join(RES, "protocol_summary.csv")
    if not os.path.exists(p):
        print("  (skipping figure 7: protocol results not present)")
        return
    s = pd.read_csv(p)
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.3))
    plt.subplots_adjust(wspace=0.46)

    ax = axes[0]
    base = s[(s.protocol != "abrupt") | (s.sigma_protocol == 1.60)]
    for proto, c, mk in (("abrupt", C["asd"], "s"), ("anchored", C["acc"], "^"),
                         ("graduated", C["acc3"], "o")):
        g = base[base.protocol == proto].groupby("K_instr").success_rate.mean()
        ax.plot(g.index, g.values, marker=mk, ms=3.8, color=c, mfc="none",
                mew=1.0, label=proto)
    ax.set_xscale("log")
    ax.set_xlabel(r"instructional coupling $K_{\mathrm{instr}}$")
    ax.set_ylabel("success rate")
    ax.set_title("Protocol efficiency")
    ax.legend(frameon=False, handlelength=1.4)
    panel(ax, "a")

    ax = axes[1]
    for proto, c, mk in (("abrupt", C["asd"], "s"), ("anchored", C["acc"], "^"),
                         ("graduated", C["acc3"], "o")):
        g = base[base.protocol == proto].groupby("K_prior").success_rate.mean()
        ax.plot(g.index, g.values, marker=mk, ms=3.8, color=c, mfc="none",
                mew=1.0, label=proto)
    ax.set_xlabel(r"prior-attractor strength $K_{\mathrm{prior}}$")
    ax.set_ylabel("success rate")
    ax.set_title("Effect of entrenchment")
    panel(ax, "b")

    ax = axes[2]
    g = s[s.protocol == "abrupt"].groupby("sigma_protocol")[["success_rate", "R"]].mean()
    ax.plot(g.index, g.success_rate, marker="s", ms=3.8, color=C["asd"],
            mfc="none", mew=1.0, label="success")
    ax.plot(g.index, g.R, marker="o", ms=3.8, color=C["k1"], mfc="none",
            mew=1.0, label=r"$\bar R$ retained")
    ax.set_xlabel(r"protocol noise $\sigma$")
    ax.set_ylabel("value")
    ax.set_title("Raising noise does not help")
    ax.legend(frameon=False, handlelength=1.4)
    panel(ax, "c")
    save(fig, "figure7_protocols")


if __name__ == "__main__":
    todo = sys.argv[1:] or ["1", "2", "3", "4", "5", "6", "7"]
    fns = {"1": fig1, "2": fig2, "3": fig3, "4": fig4, "5": fig5,
           "6": fig6, "7": fig7}
    for t in todo:
        print(f"figure {t}")
        fns[t]()
