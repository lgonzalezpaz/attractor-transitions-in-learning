"""
abn_model.py — Hierarchical Kuramoto forward model and simulation-based
inversion for Attractor-Based Neuroeducation (ABN).

FORWARD MODEL
-------------
M cognitive modules; module m contains N_m phase oscillators representing
local neuronal assemblies.  Each oscillator obeys

  dtheta_i/dt = omega_i
              + K_in  * r_m  * sin(psi_m - theta_i)          (intra-module)
              + K_out * Rbar * sin(Psibar - theta_i)         (assembly field)
              + sigma * xi_i(t)

with r_m exp(i psi_m) = <exp(i theta_j)>_{j in m} the module order parameter
and Rbar exp(i Psibar) = <exp(i psi_m)>_m the assembly (module-level) order
parameter.  Oscillator frequencies are drawn as omega_i = Omega_m + eta_i,
with Omega_m ~ N(2 pi f0, (2 pi delta_b)^2) across modules and
eta_i ~ N(0, (2 pi delta_w)^2) within modules.

Region-level signals are rendered as cos(theta_i) plus additive observation
noise, sampled at the repetition time, and passed through exactly the same
band-pass / Hilbert / order-parameter pipeline as the empirical data.  Every
measurement bias of the empirical pipeline — in particular the finite-size
error of the module mean phase — is therefore present in the simulated
observables as well, and cancels in the inversion.

INVERSION
---------
A library of simulated observable vectors is built on a grid of
(K_in, K_out, sigma).  Each participant is assigned the grid point minimising
the Euclidean distance between the empirical and simulated observable vectors,
each observable standardised by its dispersion across the empirical cohort.

License: MIT (code).
"""
from __future__ import annotations

import numpy as np

from abn_core import (BAND, CORTICAL_MODULES, OBS_KEYS, analytic_phase,
                      bandpass, observables, obs_vector)

F0 = 0.055            # Hz; centre of the analysis band
DELTA_W = 0.006       # Hz; within-module frequency SD
DELTA_B = 0.006       # Hz; between-module frequency SD (calibrated, fixed)
OBS_NOISE = 0.5       # observation-noise amplitude (calibrated)
SHARED_DRIVE = 0.4    # module-level common-drive gain (calibrated)
REC_DT = 0.5          # s; storage interval of the simulator
N_PER = (34, 21, 32, 33, 22)    # Dosenbach module sizes (default, FP, CO, SM, OC)


# ----------------------------------------------------------------------------
# Batched simulator
# ----------------------------------------------------------------------------
def simulate_batch(K_in, K_out, sigma, delta_b=0.004, n_per=N_PER,
                   T_sec=500.0, dt=0.05, f0=F0, delta_w=DELTA_W,
                   rec_dt=REC_DT, seed=0, dtype=np.float32):
    """Integrate B parameter sets simultaneously (Euler-Maruyama).

    K_in, K_out, sigma : arrays of shape (B,)
    Returns phases recorded every rec_dt, shape (B, T_rec, n_osc).
    """
    K_in = np.asarray(K_in, dtype=dtype).reshape(-1, 1)
    K_out = np.asarray(K_out, dtype=dtype).reshape(-1, 1)
    sigma = np.asarray(sigma, dtype=dtype).reshape(-1, 1)
    B = K_in.shape[0]
    n_per = np.asarray(n_per)
    M, n = len(n_per), int(n_per.sum())
    rng = np.random.default_rng(seed)

    # module indicator matrix (n x M), column-normalised for averaging
    Ind = np.zeros((n, M), dtype=dtype)
    off = np.concatenate([[0], np.cumsum(n_per)])
    for m in range(M):
        Ind[off[m]:off[m + 1], m] = 1.0 / n_per[m]
    Expand = (Ind > 0).astype(dtype)          # (n x M) membership

    Om_mod = (2 * np.pi * (f0 + rng.normal(0, delta_b, (B, M)))).astype(dtype)
    eta = (2 * np.pi * rng.normal(0, delta_w, (B, n))).astype(dtype)
    omega = (Om_mod @ Expand.T) + eta          # (B, n)

    th = rng.uniform(-np.pi, np.pi, (B, n)).astype(dtype)
    n_steps = int(round(T_sec / dt))
    keep = max(1, int(round(rec_dt / dt)))
    rec = np.empty((B, n_steps // keep, n), dtype=dtype)
    sq = np.sqrt(dt).astype(dtype)
    ri = 0
    for t in range(n_steps):
        e = np.exp(1j * th)
        zm = e @ Ind                                   # (B, M) module mean field
        rm, psim = np.abs(zm), np.angle(zm)
        zb = np.exp(1j * psim).mean(axis=1, keepdims=True)
        Rb, Psib = np.abs(zb), np.angle(zb)
        intra = (K_in * (rm @ Expand.T)) * np.sin((psim @ Expand.T) - th)
        glob = (K_out * Rb) * np.sin(Psib - th)
        th += (omega + intra + glob) * dt \
            + sigma * sq * rng.standard_normal((B, n)).astype(dtype)
        if t % keep == 0 and ri < rec.shape[1]:
            rec[:, ri] = th
            ri += 1
    return rec[:, :ri]


def render_and_measure(phases_rec, tr, n_tp, members, obs_noise=1.0,
                       rec_dt=REC_DT, seed=0, shared_drive=0.0):
    """Render recorded phases as BOLD-like region signals and measure them.

    Each region signal is

        x_i(t) = cos(theta_i) + g * cos(psi_m) + nu * xi_i ,   i in module m,

    where the second term is a module-level common drive of gain g.  It
    represents input and vascular components shared by the regions of a module
    -- afferents from a common source, a common draining territory -- and is
    required because within-module BOLD coherence empirically exceeds
    between-module coherence, which pure phase coupling at the fitted level
    cannot reproduce.  The common drive raises within-module coherence without
    altering the module phase dynamics themselves.
    """
    rng = np.random.default_rng(seed)
    idx = np.round(np.arange(n_tp) * tr / rec_dt).astype(int)
    idx = idx[idx < phases_rec.shape[1]]
    memb_of = np.zeros(phases_rec.shape[2], dtype=int)
    for m, ix in enumerate(members):
        memb_of[ix] = m
    out = []
    for b in range(phases_rec.shape[0]):
        th = phases_rec[b, idx].astype(float)
        x = np.cos(th)
        if shared_drive > 0:
            psi = np.stack([np.angle(np.exp(1j * th[:, ix]).mean(axis=1))
                            for ix in members], axis=1)
            x = x + shared_drive * np.cos(psi[:, memb_of])
        x = x + obs_noise * rng.standard_normal(x.shape)
        sd = x.std(0)
        x = (x - x.mean(0)) / np.where(sd > 0, sd, 1.0)
        xf = bandpass(x, tr)
        edge = int(np.ceil(25.0 / tr))
        if 2 * edge < xf.shape[0] - 20:
            xf = xf[edge:-edge]
        out.append(observables(analytic_phase(xf), tr, members))
    return out


# ----------------------------------------------------------------------------
# Library construction
# ----------------------------------------------------------------------------
def default_grid():
    """Grid centred on the regime identified by the coarse calibration scan:
    weak inter-module coupling, moderate noise, far from global synchrony.

    Columns: K_in, K_out, sigma.  The between-module frequency dispersion is
    held at the calibrated value DELTA_B rather than inverted, because a
    held-out recovery test showed it to be unidentifiable from these
    observables (Spearman rho = 0.08) and because including it degraded the
    recovery of the identifiable parameters.  Its value is varied in a
    sensitivity analysis instead.
    """
    K_in = np.array([0.03, 0.06, 0.10, 0.16, 0.24, 0.34, 0.48, 0.65])
    K_out = np.array([0.002, 0.004, 0.007, 0.012, 0.020, 0.030, 0.042,
                      0.057, 0.075, 0.098, 0.127, 0.165, 0.215])
    sigma = np.array([0.35, 0.45, 0.55, 0.67, 0.80, 0.95, 1.15, 1.40, 1.70])
    return np.array([[a, b, c] for a in K_in for b in K_out for c in sigma])


def build_library(grid, tr_list, n_tp_list, members, n_rep=3,
                  obs_noise=OBS_NOISE, T_sec=620.0, chunk=112, seed=1234,
                  verbose=True, shared_drive=SHARED_DRIVE, delta_b=DELTA_B):
    """Simulate the grid and measure it at every (TR, n_tp) design point."""
    import pandas as pd
    rows = []
    G = grid.shape[0]
    for rep in range(n_rep):
        for s0 in range(0, G, chunk):
            sub = grid[s0:s0 + chunk]
            rec = simulate_batch(sub[:, 0], sub[:, 1], sub[:, 2],
                                 delta_b=delta_b, T_sec=T_sec,
                                 seed=seed + 977 * rep + s0)
            for tr, n_tp in zip(tr_list, n_tp_list):
                meas = render_and_measure(rec, tr, n_tp, members,
                                          obs_noise=obs_noise,
                                          seed=seed + 31 * rep + s0,
                                          shared_drive=shared_drive)
                for i, m in enumerate(meas):
                    m = dict(m)
                    m.update(K_in=sub[i, 0], K_out=sub[i, 1],
                             sigma=sub[i, 2], delta_b=delta_b, rep=rep,
                             TR=tr, n_tp=n_tp, obs_noise=obs_noise,
                             shared_drive=shared_drive)
                    rows.append(m)
            if verbose:
                print(f"  rep{rep} {s0}-{min(s0+chunk, G)}", flush=True)
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# Inversion
# ----------------------------------------------------------------------------
def invert(emp_df, lib_df, scales, keys=OBS_KEYS, design_cols=("TR_bin", "n_tp_bin")):
    """Nearest-grid-point inversion within matched design cells.

    emp_df  : empirical observables, with the design columns present
    lib_df  : simulated library, with the same design columns
    scales  : dict observable -> scaling (typically the empirical SD)
    Returns a DataFrame with K_in_hat, K_out_hat, sigma_hat and the fit distance.
    """
    import pandas as pd
    w = np.array([1.0 / scales[k] for k in keys])
    pcols = ["K_in", "K_out", "sigma"]
    lib_mean = (lib_df.groupby(list(design_cols) + pcols)
                [list(keys)].mean().reset_index())
    out = []
    for cell, emp_cell in emp_df.groupby(list(design_cols)):
        lib_cell = lib_mean
        for c, v in zip(design_cols, cell if isinstance(cell, tuple) else (cell,)):
            lib_cell = lib_cell[lib_cell[c] == v]
        if len(lib_cell) == 0:
            continue
        L = lib_cell[list(keys)].to_numpy() * w
        P = lib_cell[pcols].to_numpy()
        E = emp_cell[list(keys)].to_numpy() * w
        d = np.linalg.norm(E[:, None, :] - L[None, :, :], axis=2)
        j = np.argmin(d, axis=1)
        res = pd.DataFrame({"K_in_hat": P[j, 0], "K_out_hat": P[j, 1],
                            "sigma_hat": P[j, 2],
                            "fit_dist": d[np.arange(len(j)), j]},
                           index=emp_cell.index)
        out.append(res)
    return pd.concat(out).reindex(emp_df.index)
