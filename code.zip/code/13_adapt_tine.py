"""
13_adapt_tine.py — Adapt the manuscript to Trends in Neuroscience and Education.

Changes applied, each traceable to the journal's guide for authors:

  * Title replaced with a shorter, question-led form that names the educational
    problem, per "Article titles should be concise and informative".
  * Abstract restructured under headings and brought under 250 words, per
    "Structure the abstract with appropriate headings" and the 250-word cap.
  * Keywords reduced to seven (the journal allows 1-7) with none containing
    "and" or "of".
  * Citations converted from superscript to the journal's bracketed numeric
    style, e.g. [3,6], numbered in order of first appearance.
  * The generative-AI declaration renamed to the exact heading the journal
    prescribes.
  * An "Educational implications" subsection added to the Discussion, to serve
    the journal's translational scope.
  * The manuscript split into a separate title page and an anonymised body,
    because the journal uses double-anonymised review. Acknowledgements and
    the competing-interest declaration move to the title page; the repository
    URL is masked in the anonymised body because it would identify the author.
  * A separate highlights file of five bullets, each at most 85 characters.
"""
from __future__ import annotations
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAN = os.path.join(ROOT, "manuscript")

TITLE = ("When can instruction dislodge an entrenched state? "
         "A feasibility boundary for attractor transitions in learning")

ABSTRACT = """**Background.** Instructional practice for autistic learners rests on a dynamical intuition: entrenched associations behave like deep attractors, abrupt demands act as destabilising noise, and intense existing interests can bridge to new content. The intuition has never been derived, so it specifies no threshold and no failure condition.

**Methods.** We formalised learning as a controlled transition of a coupled-oscillator assembly and derived closed-form expressions for escape from a phase-locked state, for the collapse of assembly coherence, and for their joint satisfiability, verifying each against direct stochastic simulation. We then estimated the model's parameters from openly shared resting-state functional MRI in 477 school-age children, 214 of them autistic, using a simulation-based inversion with validated parameter recovery, and compared every measure with stationary linear surrogates.

**Results.** Escape from a locked assembly is Arrhenius in its coupling; coherence collapses above a critical noise. Below a critical coupling the two requirements become mutually exclusive, giving a dimensionless feasibility index whose unit contour is an exact boundary: beyond it, no perturbation can both dislodge a prior state and sustain the integration new content requires. Anchoring to an already coherent attractor converts an exponentially expensive escape into an algebraically cheap entrainment. Autistic and non-autistic participants did not differ on any parameter, all confidence intervals falling within 0.38 standard deviations, and the measures barely exceeded the surrogates.

**Conclusions.** The boundary supplies a quantifiable criterion for when an instructional perturbation is dynamically viable, and bounds what resting-state imaging can currently adjudicate for educational practice."""

KEYWORDS = ("attractor dynamics; Kuramoto model; Kramers escape; feasibility "
            "boundary; metastability; autism; instructional design")

HIGHLIGHTS = [
    "Learning is modelled as a controlled transition of a coupled oscillator assembly",
    "A closed-form index marks when no perturbation can dislodge an entrenched state",
    "Anchoring to an existing attractor replaces exponential cost with algebraic cost",
    "In 477 school-age children, autistic and non-autistic dynamics did not differ",
    "Dynamic measures barely exceed stationary linear surrogates of the same data",
]

EDU_SECTION = """### Educational implications

The boundary changes what a failed instructional episode licenses one to conclude. In the infeasible regime, escalating a demand is not merely inefficient but formally self-defeating: the same perturbation that would free the learner from the prior state dissolves the integration the new state requires. A teacher who increases pressure after a failure is, in this description, moving along the one axis that cannot help. That is a different claim from the familiar advice to reduce anxiety, and it is quantitative: our protocol simulations show the abrupt route saturating at a quarter of trials and remaining there as the imposed noise is quadrupled, while assembly coherence falls monotonically.

The same simulations order the alternatives at equal instructional cost. Graduated transition reached ceiling at half the coupling the anchored route required, and entrenchment penalised the anchored route most. This runs against the common assumption that building new content inside an intense existing interest is the more powerful lever; on this model, predictable graduated sequencing is the more efficient default and interest-based anchoring is specifically a remedy for depth, with an advantage that grows without bound as attractors deepen and is negligible when they are shallow.

That dependence yields the design recommendation we regard as most actionable. The theory predicts an interaction, not a main effect: anchoring should help most for the most entrenched content and the most rigid learners, and should be roughly equivalent to graduated sequencing otherwise. A trial that delivers one strategy to an unstratified group will therefore dilute a real interaction into a small average effect, which is what meta-analyses of structured teaching and naturalistic developmental interventions report [15,16,17,18]. The consolidation result adds a timing prediction with a measurable time constant: the benefit of preventing an initial error should grow with the delay before correction is attempted.

Our own data constrain how such stratification should be done. Because no dynamical or latent parameter distinguished autistic from non-autistic participants, diagnosis is a poor proxy for the quantity the theory cares about. Stratification should use a measured dynamical variable, and the most practical candidates are behavioural rather than imaging-based: the rate of bistable perceptual alternation [66,67] and spontaneous task-switching latency [6] both give direct access to escape times at a fraction of the cost of scanning.

None of this is yet an intervention result, and we do not present it as one. The contribution is a criterion for designing and interpreting such trials, together with an explicit statement of the regime in which a widely used instructional intuition is formally correct and the regime in which it is not."""


def strip_sup(s: str) -> str:
    """Superscript citations -> bracketed numeric style."""
    return re.sub(r"\^([\d]+(?:,[\d]+)*)\^", lambda m: "[" + m.group(1) + "]", s)


def main():
    src = open(os.path.join(MAN, "manuscript.md")).read()

    # ---- title -------------------------------------------------------
    body = src.split("\n")
    assert body[0].startswith("# ")
    body[0] = "# " + TITLE
    s = "\n".join(body)

    # ---- abstract ----------------------------------------------------
    head, rest = s.split("## Abstract", 1)
    old_abs, tail = rest.split("**Keywords:**", 1)
    tail_rest = tail.split("\n", 1)[1]
    s = (head + "## Abstract\n\n" + ABSTRACT + "\n\n**Keywords:** "
         + KEYWORDS + "\n" + tail_rest)

    # ---- educational implications ------------------------------------
    anchor = "The limitations are substantial and we prefer to be explicit about them."
    assert anchor in s
    s = s.replace(anchor, EDU_SECTION + "\n\n### Limitations\n\n" + anchor)

    # ---- AI declaration heading --------------------------------------
    s = s.replace(
        "## Declaration of Generative AI and AI-Assisted Technologies in the "
        "Writing Process",
        "## Declaration of generative AI and AI-assisted technologies in the "
        "manuscript preparation process")

    # ---- citation style ----------------------------------------------
    s = strip_sup(s)
    # affiliation markers were superscript too; restore them literally
    s = s.replace("[AUTHOR][1],\\*", "[AUTHOR]1,*").replace("[1] [AFFILIATION]",
                                                            "1 [AFFILIATION]")

    # ---- split title page from anonymised body -----------------------
    marker = "## Abstract"
    title_block, rest = s.split(marker, 1)
    anon = "# " + TITLE + "\n\n" + marker + rest

    # remove identifying back matter from the anonymised body
    anon = anon.replace(
        "**[AUTHOR]:** Conceptualization",
        "**[Author 1]:** Conceptualization")
    anon = re.sub(
        r"All analysis code, the exact participant identifiers.*?No restricted-access data were used\.",
        "All analysis code, the exact participant identifiers retained after "
        "quality control, the simulation grid and library, every derived "
        "participant-level quantity, the full statistical output, and the "
        "scripts that generate every figure are archived in a public "
        "repository and permanently on Zenodo; the identifiers are withheld "
        "here because they would reveal the authorship, and will be supplied "
        "to the editor on request and inserted on acceptance. The repository "
        "includes a pinned environment specification and a single driver "
        "script that reproduces every number and figure in this manuscript "
        "from the public data. No restricted-access data were used.",
        anon, flags=re.S)

    # the competing-interest declaration moves to the title page
    comp = ("## Declaration of Competing Interest\n\nThe author declares no "
            "competing financial interests or personal relationships that "
            "could have appeared to influence the work reported in this "
            "paper.\n\n")
    anon = anon.replace(comp, "")

    title_page = f"""# {TITLE}

[AUTHOR]1,*

1 [AFFILIATION — full postal address, including country]

*Corresponding author: [AUTHOR], [FULL POSTAL ADDRESS], [COUNTRY]. E-mail: [EMAIL]

## Acknowledgements

The author thanks [NAMES] for comments on an earlier draft. This study used
data from the Autism Brain Imaging Data Exchange, and the author thanks the
contributing sites and the Preprocessed Connectomes Project for making the
data and their derivatives openly available.

## Declaration of Competing Interest

The author declares no competing financial interests or personal relationships
that could have appeared to influence the work reported in this paper.

## Funding

This research received no specific grant from any funding agency in the
public, commercial, or not-for-profit sectors.

## Data and code availability

All analysis code, the retained participant identifiers, the simulation
library, every derived participant-level quantity, the full statistical output
and the figure scripts are archived at
https://github.com/[USER]/attractor-feasibility-learning and permanently at
Zenodo under DOI [ZENODO DOI], release v1.0.0.
"""

    open(os.path.join(MAN, "tine_title_page.md"), "w").write(title_page)
    open(os.path.join(MAN, "tine_manuscript_anonymized.md"), "w").write(anon)
    open(os.path.join(MAN, "tine_highlights.md"), "w").write(
        "## Highlights\n\n" + "\n".join("- " + h for h in HIGHLIGHTS) + "\n")

    # ---- checks ------------------------------------------------------
    print(f"title: {len(TITLE.split())} words")
    aw = len(re.sub(r"\*\*[^*]+\.\*\*", "", ABSTRACT).split())
    print(f"abstract: {aw} words excluding headings "
          f"({len(ABSTRACT.split())} including)")
    print(f"keywords: {len(KEYWORDS.split(';'))}")
    for h in HIGHLIGHTS:
        flag = "OK " if len(h) <= 85 else "TOO LONG"
        print(f"  highlight {len(h):3d} chars {flag}: {h}")
    left = re.findall(r"\^[\d,]+\^", anon)
    print(f"superscript citations remaining: {len(left)}")
    nums = sorted({int(x) for m in re.findall(r"\[([\d,]+)\]", anon)
                   for x in m.split(",") if x.isdigit()})
    print(f"bracketed citations: {min(nums)}-{max(nums)}, "
          f"gaps {[i for i in range(1, max(nums)+1) if i not in nums]}")
    for bad in ("github.com/[USER]", "[EMAIL]"):
        print(f"identifying string '{bad}' in anonymised body: {bad in anon}")


if __name__ == "__main__":
    main()
